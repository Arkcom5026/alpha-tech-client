import axios from 'axios';
import { toast } from 'react-toastify';

export const currentEmployee = async(token) => await axios.post('http://localhost:5000/api/current-employee',
    {}, {
    headers: {
        Authorization: `Bearer ${token}`
    }
})

export const currentAdminEmployee = async(token) => await axios.post('http://localhost:5000/api/current-admin-employee',
    {}, {
    headers: {
        Authorization: `Bearer ${token}`
    }
})
