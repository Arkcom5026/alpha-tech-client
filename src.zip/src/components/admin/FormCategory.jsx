import React, { useState, useEffect } from 'react'

import useAlphaTechStore from '../../store/alphatech-store'
import { toast } from 'react-toastify';

const FormCategory = () => {
    //Javascript code
    const token = useAlphaTechStore((state) => state.token)
    const [name, setName] = useState('')
   // const [categorier, setCategories] = useState([])
   const categorier = useAlphaTechStore((state)=>state.categories)
   const getCategory = useAlphaTechStore((state)=>state.getCategory)

    useEffect(() => {
        getCategory(token)
    }, [])



    const handleSupmit = async (e) => {
        //code
        e.preventDefault()
        if (!name) {
            return toast.warning('Please fill data')
        }
        //console.log(token,{name})
        try {
            const res = await createCategory(token, { name })
            console.log(res.data.name)
            toast.success(`Add Category ${res.data.name} Success!!!`)
            getCategory(token)
        } catch (err) {
            console.log(err)
        }
    }

    const handleRemove = async (id) => {
        //code

        try {
            const res = await removeCategory(token,id)
            console.log(res)
            toast.success(`Deleted ${res.data.name} success`)
            getCategory(token)
        } catch (err) {
            console.log(err)
        }
    }

    return (
        <div className='container mx-auto p-4 bg-white shadow-md'>
            <h1>Category Management</h1>
            <form className='my-4' onSubmit={handleSupmit} >
                <input
                    onChange={(e) => setName(e.target.value)}
                    className='border mr-5'
                    type='text'
                >

                </input>

                <button className='bg-blue-500'> Add Cate Category </button>

            </form>

            <hr />

            <ul className='list-none' >
                {
                    categorier.map((item, index) =>

                        <li className='flex justify-between my-2' key={index}>
                            <span>
                                {item.name}
                            </span>

                            <button
                                className='bg-red-500 '
                                onClick={() => handleRemove(item.id)}
                            >
                                Delete</button>
                        </li>
                    )
                }

            </ul>



        </div >
    )
}

export default FormCategory