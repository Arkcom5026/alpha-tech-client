import React, { useState, useEffect } from 'react'
import useAlphaTechStore from '../../store/alphatech-store'
import { createProduct, listProduct, readProduct, updateProduct, removeFiles } from '../../api/product'
import { toast } from 'react-toastify';
import Uploadfile from './Uploadfile';
import { useParams, useNavigate } from 'react-router-dom';


const initialState = {
    title: '',
    description: '',
    price: '',
    categoryId: '',
    quantity: '',
    images: []
}


const FormEditProduct = () => {
    const { id } = useParams()
    const navigate = useNavigate()
    const token = useAlphaTechStore((state) => state.token)

    const getCategory = useAlphaTechStore((state) => state.getCategory)
    const categories = useAlphaTechStore((state) => state.categories)

    const [form, setForm] = useState(initialState)

    useEffect(() => {
        //code
        getCategory()
        fetchProduct(token, id, form)

    }, [])



    //console.log(categories)

    const fetchProduct = async (token, id, form) => {
        try {
            const res = await readProduct(token, id, form)

            setForm(res.data)

        } catch (err) {
            console.log('Err fetch data', err)
        }
    }


    const handleOnChang = (e) => {
        //  console.log(e.target.name, e.target.value)
        setForm({
            ...form,
            [e.target.name]: e.target.value
        })
    }


    const handleSupmit = async (e) => {
        e.preventDefault()
        try {

            const res = await updateProduct(token, id, form)
            getProduct()
            toast.success(` แก้ไขข้อมูล ${res.data.title} สำเร็จ`)
            navigate('/admin/product')

        } catch (err) {
            console.log(err)
        }
    }

    const handleRemoveFile = (index) => {
        console.log(index)
        //setFiles(prev => prev.filter((_, i) => i !== index));

    }

    const handleDelete = (public_id) => {
        // console.log(public_id)
        removeFiles(token, public_id)
            .then((res) => {
                toast.error(res.data)
            })
            .catch((err) => {
                console.log(err)
            })
    }

    return (
        <div className='container mx-auto p-4 bg-white shadow-md'>
            <form onSubmit={handleSupmit}>
                <h1>เพิ่มข้อมูลสินค้า</h1>
                <input
                    className='border'
                    value={form.title}
                    onChange={handleOnChang}
                    placeholder='title'
                    name='title'
                />
                <input
                    className='border'
                    value={form.description}
                    onChange={handleOnChang}
                    placeholder='description'
                    name='description'
                />
                <input
                    type='number'
                    className='border'
                    value={form.price}
                    onChange={handleOnChang}
                    placeholder='price'
                    name='price'
                />
                <input
                    type='number'
                    className='border'
                    value={form.quantity}
                    onChange={handleOnChang}
                    placeholder='quantity'
                    name='quantity'

                />

                <select
                    className='border'
                    name='categoryId'
                    onChange={handleOnChang}
                    required
                    value={form.categoryId}

                >
                    <option value="" disabled> Pleace Select</option>
                    {
                        categories.map((item, index) =>
                            <option key={index} value={item.id}> {item.name}</option>
                        )

                    }

                </select>
                <hr />


                {/* Update file */}
                {
                    < Uploadfile form={form} setForm={setForm} />
                }

                <button className='bg-blue-500'> แก้ไขข้อมูลสินค้า </button>

                <hr />
                <br />



            </form>
        </div>
    )
}


export default FormEditProduct