import React, { useState, useEffect } from 'react'
import useAlphaTechStore from '../../store/alphatech-store'
import { createProduct, deleteProduct } from '../../api/product'
import { toast } from 'react-toastify';
import Uploadfile from './Uploadfile';
import { Link } from 'react-router-dom';
import { Pencil,Trash2 } from 'lucide-react';
import { numberFormat } from '../../utils/number';
import { dateFormat } from '../../utils/dataformat';

const initialState = {
    title: '',
    description: '',
    price: '',
    categoryId: '',
    quantity: '',
    images: []
}


const FormProduct = () => {
    
    const token = useAlphaTechStore((state) => state.token)

    const getCategory = useAlphaTechStore((state) => state.getCategory)
    const categories = useAlphaTechStore((state) => state.categories)

    const getProduct = useAlphaTechStore((state) => state.getProduct)
    const products = useAlphaTechStore((state) => state.products)


    const [form, setForm] = useState(initialState)

    useEffect(() => {
        //code
        getCategory()
        getProduct(50)

    }, [])
    //console.log(categories)

    const handleOnChang = (e) => {        
        setForm({
            ...form,
            [e.target.name]: e.target.value
        })

    }

    const handleSupmit = async (e) => {
        e.preventDefault()
        try {
            const res = await createProduct(token, form)
            toast.success(`เพิ่มข้อมูล ${res.data.title} สำเร็จ`)
            navigate('/admin/product')
        } catch (err) {
            console.log(err)
        }

    }

    const handleDelete = async (id) => {

        if (window.confirm('คุณต้องการลบข้อมูลสินค้า ')) {
            try {
                const res = await deleteProduct(token, id)
                toast.success(`ลบข้อมูลสำเร็จ`)
                navigate('/admin/product')
                //console.log(res)
            } catch (err) {
                console.log(err)
            }
        }

    }

    return (
        <div className='container mx-auto p-4 bg-white shadow-md'>
            <form onSubmit={handleSupmit}>
                <h1 > เพิ่มข้อมูลสินค้า </h1>
                <input
                    className='border'
                    value={form.title}
                    onChange={handleOnChang}
                    placeholder='title'
                    name='title'
                />
                <input
                    className='border'
                    value={form.description}
                    onChange={handleOnChang}
                    placeholder='description'
                    name='description'
                />
                <input
                    type='number'
                    className='border'
                    value={form.price}
                    onChange={handleOnChang}
                    placeholder='price'
                    name='price'
                />
                <input
                    type='number'
                    className='border'
                    value={form.quantity}
                    onChange={handleOnChang}
                    placeholder='quantity'
                    name='quantity'

                />

                <select
                    className='border'
                    name='categoryId'
                    onChange={handleOnChang}
                    required
                    value={form.categoryId}

                >
                    <option value="" disabled> Pleace Select</option>
                    {
                        categories.map((item, index) =>
                            <option key={index} value={item.id}> {item.name}</option>
                        )

                    }

                </select>
                <hr />

                {/* Upload file */}
                <Uploadfile form={form} setForm={setForm} />


                <button className='bg-blue-500 p-2 rounded hover:scale-105 hover:-translate-y-1 hover:duration-200 shadow-md '> เพิ่มสินค้า </button>

                <hr />
                <br />

                <table className="table w-full ">
                    <thead>
                        <tr className='bg-blue-200 border'>
                            <th scope="col">#</th>
                            <th scope="col">รูปภาพ</th>
                            <th scope="col">ชื่อสินค้า</th>
                            <th scope="col">รายละเอียด</th>
                            <th scope="col">ราคา</th>
                            <th scope="col">คงเหลือ</th>
                            <th scope="col">ขายรวม</th>
                            <th scope="col">วันที่อัปเดต</th>
                            <th scope="col">จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            products.map((item, index) => {
                                //console.log(item.images)
                                return (
                                    <tr key={index}>
                                        <th scope="row">{index + 1}</th>
                                        <td>
                                            {
                                                item.images.length > 0 ? (
                                                    item.images.map((image, index) => (
                                                      <img
                                                        key={index}
                                                        className="w-24 h-24 rounded-lg shadow-md mx-1"
                                                        src={image.url}  // ใช้ `image.url` โดยตรง
                                                      />
                                                    ))
                                                )       
                                                    : <div
                                                        className='w-24 h-24 bg-gray-200 rounded-lg shadow-sm flex items-center justify-center'
                                                    >  No Image

                                                    </div>                                            
                                            }
                                        </td>
                                        <td>{item.title}</td>
                                        <td>{item.description}</td>
                                        <td>{numberFormat(item.price)}</td>
                                        <td>{item.quantity}</td>
                                        <td>{item.sold}</td>
                                        <td>{dateFormat(item.updateAt)}</td>

                                        <td className='flex gap-2  justify-center items-center'>
                                            <p className='bg-yellow-300 rounded-md p-1 
                                                hover:scale-105 hover:-translate-y-1 hover:duration-200 shadow-md 
                                            '>
                                                <Link to={'/admin/product/' + item.id}>   <Pencil /> </Link>
                                            </p>
                                            <p className='bg-red-500 rounded-md p-1 hover:scale-105 hover:-translate-y-1 hover:duration-200 shadow-md  '
                                                onClick={() => handleDelete(item.id)}
                                            >
                                                 <Trash2 />
                                            </p>
                                        </td>

                                    </tr>
                                )
                            })
                        }


                    </tbody>
                </table>

            </form>
        </div>
    )
}

export default FormProduct