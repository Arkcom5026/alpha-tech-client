import React from 'react'

const HeaderAdmin = () => {
    return (
        <header className='bg-white h-16  flex items-center px-6'>
            HeaderAdmin
        </header>
    )
}

export default HeaderAdmin