import React, { useState, useEffect } from 'react';
import Resizer from 'react-image-file-resizer';
import useAlphaTechStore from '../../store/alphatech-store';
import { removeFiles, uploadFiles } from '../../api/product';
import { toast } from 'react-toastify';
import { Pencil,Trash2 } from 'lucide-react';

const MAX_FILE_SIZE = 5 * 1024 * 1024;

const UpdatedFile = ({ form, setForm }) => {



  //console.log(form)

  const [isLoading, setIsLoading] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');
  const [files, setFiles] = useState([]);

  const token = useAlphaTechStore((state) => state.token);



  const resizeImage = (form) => {
    return new Promise((resolve, reject) => {
      Resizer.imageFileResizer(
        form,
        720,
        720,
        'JPEG',
        100,
        0,
        uri => uri ? resolve(uri) : reject(new Error('ปรับขนาดไม่สำเร็จ')),
        'base64',
        reject
      );
    });
  };

  const validateFile = (file) => {
    if (!file.type?.startsWith('image/')) {
      throw new Error(`"${file.name}" ไม่ใช่ไฟล์รูปภาพ`);
    }
    if (file.size > MAX_FILE_SIZE) {
      throw new Error(`"${file.name}" ขนาดเกิน 5MB`);
    }
  };

  const handleAddFile = async (e) => {
    const selected = e.target.files;
    if (!selected?.length) return setError('กรุณาเลือกไฟล์');

    setIsResizing(true);
    setError('');  // reset error เมื่อเริ่มต้นใหม่
    setProgress(0);

    e.target.disabled = true;

    const filesArray = Array.from(selected);
    const base64Files = [];

    try {
      for (let i = 0; i < filesArray.length; i++) {
        const file = filesArray[i];
        try {
          validateFile(file);
          const base64 = await resizeImage(file);
          base64Files.push({ base64 });

          setProgress(Math.round(((i + 1) / filesArray.length) * 50));

        } catch (err) {
          console.warn(err.message);
          setError(prev => prev + '\n' + err.message);
        }
      }

      if (base64Files.length === 0) throw new Error('ไม่มีไฟล์ที่ผ่านการตรวจสอบ');


      let allFiles = form.images

      
               const response = await uploadFiles(token, base64Files)
                 .then((response) => {         
                   setFiles(prev => [...prev, response.data]);
                   allFiles.push(response.data)
                   setForm({
                     ...form,
                     images: allFiles
                   })
                   toast.success('Upload image Sucess!!!')
                 })
                 .catch(() => {
                   console.log(err)
                 })
         
      
                setProgress(100);
                

    } catch (err) {
      setError(err.message || 'เกิดข้อผิดพลาด');
    } finally {
      setIsResizing(false);
      setIsLoading(false);
      setTimeout(() => setProgress(0), 1500);  // รีเซ็ต progress หลังจาก 1.5 วินาที
      e.target.disabled = false;
      e.target.value = '';  // ล้างค่าไฟล์หลังการอัปโหลด
    }
  };


  const handleRemoveFile = (indexToRemove) => {
    setForm(prevForm => ({
      ...prevForm,
      images: prevForm.images.filter((_, index) => index !== indexToRemove)
    }));
  };

  const handleDelete = async (public_id, indexToRemove) => {
    try {
      await removeFiles(token, public_id);
      toast.success("ลบไฟล์สำเร็จ");

      setForm(prevForm => ({
        ...prevForm,
        images: prevForm.images.filter((_, index) => index !== indexToRemove)
      }));
    } catch (err) {
      toast.error("ลบไฟล์ไม่สำเร็จ");
      console.error(err);
    }
  };
  const imageCount = form.images ? form.images.length : 0;



  return (
    <div style={{ padding: 20 }}>
      <h2>อัปโหลดไฟล์</h2>
      <input
        type="file"
        onChange={handleAddFile}
        accept="image/*"
        multiple
        disabled={isResizing || isLoading}
        style={{ marginBottom: 20 }}
      />

      {(isResizing || isLoading) && (
        <div style={{ margin: '10px 0' }}>
          <p>{isResizing ? 'กำลังปรับขนาดรูปภาพ...' : 'กำลังอัปโหลด...'}</p>
          <div style={{ width: '100%', backgroundColor: '#ddd' }}>
            <div
              style={{
                width: `${progress}%`,
                height: 20,
                backgroundColor: 'blue',
                color: 'white',
                textAlign: 'center'
              }}
            >
              {progress}%
            </div>
          </div>
        </div>
      )}

      {error && <div style={{ color: 'red', marginBottom: 10 }}>{error}</div>}

      <h3>ไฟล์ที่เลือกแล้ว ({imageCount})</h3>
      <ul style={{ padding: 0, listStyle: 'none' }}>

        {form.images.map((item, index) => (
          <li key={index} style={{ display: 'flex', alignItems: 'center', marginBottom: 10 }}>

            <span style={{ flex: 1 }}>

              <div>
                <img
                  className='w-24 h24 hover:scale-105'
                  src={form.images[index].url}
                />
              </div>

            </span>

            <button
              onClick={() => { handleRemoveFile(index); handleDelete(item.public_id) }}  
              disabled={isLoading}

              style={{
                backgroundColor: '#f44336',
                color: 'white',
                border: 'none',
                padding: '5px 10px',
                borderRadius: 4,
                cursor: 'pointer'
              }}
            >
              <Trash2 />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );

}

export default UpdatedFile
