import React, { useState, useEffect } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import zxcvbn from "zxcvbn";
import { useForm } from "react-hook-form";

const registerSchema = z
  .object({
    email: z.string().email({ message: "กรุณาใส่ Email ให้ถูกต้อง" }),
    password: z.string().min(8, { message: "Password ต้องมากกว่า 8 ตัวอักษร" }),
    tel: z.string()
      .min(10, { message: "กรุณาใส่เบอร์โทรให้ครบ" })
      .max(10, { message: "เบอร์โทรเกิน" })
      .regex(/^0[689]\d{8}$/, {
        message: "กรุณาใส่เบอร์โทรศัพท์ที่ถูกต้อง (ขึ้นต้นด้วย 06, 08, 09)"
      }),
    branch: z.string().min(1, { message: "กรุณาเลือกสาขา" }),
    position: z.string().min(1, { message: "กรุณาเลือกตำแหน่ง" }),

  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Password ไม่ตรงกัน",
    path: ["confirmPassword"],
  });


const PosRegister = () => {

  const [passwordScore, setPasswordScore] = useState(0);



  const { 
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(registerSchema),
  })

  const validatePassword = () => {
    let password = watch().password;
    return zxcvbn(password ? password : "").score;
  }

  useEffect(() => {
    setPasswordScore(validatePassword());
  }, [watch().password])

  const onSubmit = async (data) => {

    try {
      const res = await axios.post("http://localhost:5000/api/registeruser", data);

      console.log(res.data);
      toast.success(res.data);
    } catch (err) {
      const errMsg = err.response?.data?.message;
      toast.error(errMsg);
      console.log(err);
    }
  };


  const selectedPosition = watch("position");

  return (

    <div
      className="min-h-screen flex 
  items-center justify-center bg-gray-100"
    >
      <div className="w-full shadow-md bg-white p-8 max-w-md">
        <h1 className="text-2xl text-center my-4 font-bold">ลงทะเบียนพนักงาน</h1>

        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="space-y-4">

            <div>
              <input
                {...register("email")}
                placeholder="Email"
                className={`border w-full px-3 py-2 rounded
          focus:outline-none focus:ring-2 focus:ring-blue-500
          focus:border-transparent
          ${errors.email && "border-red-500"}
          `}
              />
              {errors.email && (
                <p className="text-red-500 text-sm">{errors.email.message}</p>
              )}
            </div>

            <div>
              <input
                {...register("password")}
                placeholder="Password"
                type="password"
                className={`border w-full px-3 py-2 rounded
            focus:outline-none focus:ring-2 focus:ring-blue-500
            focus:border-transparent
            ${errors.password && "border-red-500"}
            `}
              />

              {errors.password && (
                <p className="text-red-500 text-sm">
                  {errors.password.message}
                </p>
              )}
              {watch().password?.length > 0 && (
                <div className="flex mt-2">
                  {Array.from(Array(5).keys()).map((item, index) => (
                    <span className="w-1/5 px-1" key={index}>
                      <div
                        className={`rounded h-2 ${passwordScore <= 2
                          ? "bg-red-500"
                          : passwordScore < 4
                            ? "bg-yellow-500"
                            : "bg-green-500"
                          }
            `}
                      ></div>
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div>
              <input {...register("confirmPassword")}
                type="password"
                placeholder="Confirm Password"
                className={`border w-full px-3 py-2 rounded
              focus:outline-none focus:ring-2 focus:ring-blue-500
              focus:border-transparent
              ${errors.confirmPassword && "border-red-500"}
              `}
              />


              {errors.confirmPassword && (
                <p className="text-red-500 text-sm">{errors.confirmPassword.message}</p>
              )}
            </div>

            <div>
              <input
                {...register("tel")}
                placeholder="เบอร์โทร (เช่น 0812345678)"
                type="tel"  // เปลี่ยนจาก number เป็น tel
                maxLength={10}
                className={`border w-full px-3 py-2 rounded
      focus:outline-none focus:ring-2 focus:ring-blue-500
      focus:border-transparent
      ${errors.tel && "border-red-500"}
    `}
                onInput={(e) => {
                  // จำกัดให้ใส่ได้เฉพาะตัวเลข
                  e.target.value = e.target.value.replace(/\D/g, '').slice(0, 10);
                }}
              />
              {errors.tel && (
                <p className="text-red-500 text-sm">{errors.tel.message}</p>
              )}
            </div>


            <div className="mb-4">
              <select
                {...register("branch")}
                className={`border w-full px-3 py-2 rounded
      focus:outline-none focus:ring-2 focus:ring-blue-500
      focus:border-transparent ${selectedPosition === "" ? "text-gray-400" : "text-black"}`}
                defaultValue=""
              >
                <option value="" disabled >สาขา</option>
                <option value="sales" className="text-black">บรรพตพิสัย</option>
                <option value="technician" className="text-black">บึงสามัคคี</option>
              </select>
              {errors.position && (
                <p className="text-red-500 text-sm">{errors.branch.message}</p>
              )}
            </div>


            <div className="mb-4">
              <select
                {...register("position")}
                className={`border w-full px-3 py-2 rounded
      focus:outline-none focus:ring-2 focus:ring-blue-500
      focus:border-transparent ${selectedPosition === "" ? "text-gray-400" : "text-black"}`}
                defaultValue=""
              >
                <option value="" disabled >ตำแหน่ง</option>
                <option value="sales" className="text-black">พนักงานขาย</option>
                <option value="technician" className="text-black">ช่างเทคนิค</option>
              </select>
              {errors.position && (
                <p className="text-red-500 text-sm">{errors.position.message}</p>
              )}
            </div>


            <button
              className="bg-blue-500 rounded-md
           w-full text-white font-bold py-2 shadow
           hover:bg-blue-700
           ">
              Register
            </button>


          </div>
        </form>
      </div>
    </div>
  )
}

export default PosRegister