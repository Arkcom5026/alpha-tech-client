import React, { useState, useEffect } from 'react'
import { listUserCart, saveAddress } from '../../api/user'
import useAlphaTechStore from '../../store/alphatech-store'
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import { numberFormat } from '../../utils/number';

const SummaryCard = () => {
  const token = useAlphaTechStore((start) => start.token)
  const [products, setProducts] = useState([])
  const [cartTotal, setcartTotal] = useState(0)

  const [address, setAddress] = useState('')
  const [addressSave, setAddressSave] = useState(false)

  const navigate = useNavigate()
  
  useEffect(() => {
    handleUserCart(token)
  }, [])

  const handleUserCart = () => {
    listUserCart(token)
      .then((res) => {     
        setProducts(res.data.products)
        setcartTotal(res.data.cartTotal)
      })
      .catch((err) => {
        console.log(err)
      })

  }

  const handleSaveAddress = () => {
    if (!address) {
      return toast.warning('Please fill address')
    }
    saveAddress(token, address)
      .then((res) => {       
        toast.success(res.data.message)
        setAddressSave(true)
      })
      .catch((err) => {
        console.log(err)
      })
  }

  const handleGoToPayment = () => {
    if(!addressSave){
      return toast.warning('กรุณากรอกที่อยู่')
    }
    navigate('/user/payment')
    
  }


  return (
    <div className='mx-auto'>
      <div className='flex flex-wrap '>
        {/* Left */}
        <div className='w-2/4 p-2'>
          <div className='bg-blue-100 p-4 rounded-md border shadow-md space-y-2'>
            <h1 className='font-bold text-lg'> ที่อยู่ในการจัดส่ง </h1>

            <textarea
              required
              onChange={(e) => setAddress(e.target.value)}
              placeholder='กรุณากรอกที่อยู่จัดส่ง'
              className='w-full px-2 rounded-md'
            />

            <button
              onClick={handleSaveAddress}
              className='bg-blue-500 text-white px-4 py-2 rounded-md shadow-md hover:bg-blue-700 hover:scale-105 hover:duration-200'>
              Save Address
            </button>

          </div>
        </div>


        {/* Left */}
        <div className='w-2/4 p-2'>
          <div className='bg-blue-100 p-4 rounded-md border shadow-md space-y-4'>
            <h1 className='text-lg font-bold'> รายการสั่งซื้อ </h1>

            {/* Item List*/}

            {
              products?.map((item, index) =>
                <div key={index}>
                  <div className='flex justify-between items-end '>
                    {/* left */}
                    <div>
                      <p className='font-bold'> {item.product.title} </p>
                      <p className='text-sm'> {item.count} x {numberFormat(item.product.price)}</p>
                    </div>

                    {/* rigth */}
                    <div>
                      <p className='text-blue-700 font-bold'> {numberFormat(item.count * item.product.price)} </p>
                    </div>

                  </div>
                </div>
              )
            }


            <div className='flex justify-between'>
              <p>ค่าจัดส่ง</p>
              <p>0.00</p>
            </div>

            <div className='flex justify-between'>
              <p>ส่วนลด</p>
              <p>0.00</p>
            </div>
            <div className='flex justify-between font-bold '>
              <p className='font-bold'>ยอดรวมสุทธิ</p>
              <p className='text-lg text-blue-700'>{numberFormat(cartTotal)}</p>
            </div>
            <hr />
            <div>
              <button
                onClick={handleGoToPayment}
               
                className='bg-blue-500 w-full p-2 rounded-md shadow-md text-white hover:bg-blue-700'>
                  ดำเนินการชำระเงิน
              </button>
            </div>
          </div>

        </div>

      </div>


    </div>
  )
}

export default SummaryCard

