import React, { useState, useEffect } from 'react'
import { listProductBy } from '../../api/product'
import ProductCard from '../card/ProductCard'
import { SwiperSlide } from 'swiper/react'
import SwiperShowProducts from '../../utils/SwiperShowProducts'

const NewProduct = () => {

    const [data, setData] = useState([])

    useEffect(() => {

        loadData()
    }, [])

    const loadData = () => {
        listProductBy('updatedAt', 'desc', 3)
            .then((res) => {
             //   console.log('res ', res)
                setData(res.data)
            })
            .catch((err) => {
                console.log('loadData err --> ', err)
            })
    }

    return (
        <SwiperShowProducts>

            {data?.map((item, index) => (
                <SwiperSlide>
                    <ProductCard item={item} key={index} />
                </SwiperSlide>

            ))}

        </SwiperShowProducts>

    )
}

export default NewProduct