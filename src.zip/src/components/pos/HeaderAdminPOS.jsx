import React from 'react'

const HeaderAdminPOS = () => {
    return (
        <header className='bg-white h-16  flex items-center px-6'>
            HeaderAdminPOS
        </header>
    )
}

export default HeaderAdminPOS