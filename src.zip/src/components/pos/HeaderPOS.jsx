import { useEffect } from "react";
import { NavLink } from 'react-router-dom';
import useAlphaTechStore from "../../store/alphatech-store";

import { 
  FaShoppingCart, 
  FaCog, 
  FaUserCircle, 
  FaSignOutAlt,
  FaShoppingBasket,
  FaTools,
  FaChartBar,
  FaMoneyBillWave,
  FaBoxes
} from 'react-icons/fa';




const HeaderPOS = () => {

  const branchName = useAlphaTechStore((state) => state.branchName);

  // useEffect(() => {

  
  // }, []);
  
  const navLinkClass = ({ isActive }) =>
    `px-5 py-2.5 rounded-lg flex items-center gap-2 transition-all duration-300 ease-in-out ${
      isActive
        ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-md font-medium'
        : 'text-white hover:bg-blue-600 hover:shadow-md font-normal hover:font-medium'
    }`;

  return (
    <div className="flex items-center justify-between bg-gradient-to-r from-blue-700 to-blue-600 px-6 py-3 shadow-lg">
      {/* ส่วนเมนูด้านซ้าย */}
      <div className="flex items-center gap-3">
        {/* เมนูจัดซื้อ */}
        <NavLink to="/pos/purchases" className={navLinkClass} end>
          <FaShoppingCart className="text-lg" />
          <span>จัดซื้อ</span>
        </NavLink>

        {/* เมนูการขาย */}
        <NavLink to="/pos/sales" className={navLinkClass} end>
          <FaShoppingBasket className="text-lg" />
          <span>การขาย</span>
        </NavLink>

        {/* เมนูรับซ่อม */}
        <NavLink to="/pos/services" className={navLinkClass} end>
          <FaTools className="text-lg" />
          <span>บริการ</span>
        </NavLink>

        {/* เมนูการเงิน */}
        <NavLink to="/pos/finance" className={navLinkClass} end>
          <FaMoneyBillWave className="text-lg" />
          <span>การเงิน</span>
        </NavLink>

        {/* เมนูสต๊อกสินค้า */}
        <NavLink to="/pos/stock" className={navLinkClass} end>
          <FaBoxes className="text-lg" />
          <span>สต๊อกสินค้า</span>
        </NavLink>

        {/* เมนูรายงาน */}
        <NavLink to="/pos/reports" className={navLinkClass} end>
          <FaChartBar className="text-lg" />
          <span>รายงาน</span>
        </NavLink>
      </div>

      {/* ส่วนด้านขวา - ชื่อสาขาและเมนูผู้ใช้ */}
      <div className="flex items-center gap-4">
        {/* ชื่อสาขา - ปรับให้เด่นขึ้น */}
        {branchName && (
          <div className="flex items-center gap-2">
            <span className="text-white font-semibold text-lg bg-blue-800/50 px-4 py-1.5 rounded-full shadow-md">
              สาขา: {branchName}
            </span>
          </div>
        )}

        {/* เมนูผู้ใช้ */}
     {/*    <div className="flex items-center gap-2">
          <NavLink to="/pos/settings" className={navLinkClass}>
            <FaCog className="text-lg" />
            <span>ตั้งค่า</span>
          </NavLink>
          
          <NavLink to="/pos/profile" className={navLinkClass}>
            <FaUserCircle className="text-lg" />
            <span>โปรไฟล์</span>
          </NavLink>


          <NavLink to="/pos/logoutpos" className={navLinkClass}>
            <FaSignOutAlt className="text-lg" />
            <span>ออกจากระบบ</span>
          </NavLink>
        </div>*/}
      </div>
    </div>
  );
};

export default HeaderPOS;