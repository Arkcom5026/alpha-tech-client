import React, { useState } from "react";
import axios from "axios";
import { toast } from 'react-toastify';
import useAlphaTechStore from "../../store/alphatech-store";
import { useNavigate } from 'react-router-dom';

const authPosLogin = () => {
    const actionLogin = useAlphaTechStore((state) => state.actionLogin)
    const user = useAlphaTechStore((state) => state.user)
    const navigate = useNavigate()
  
   // console.log('user form zustand', user)
  
    const [form, setForm] = useState({
  
      email: "",
      password: "",
  
    })
  
    const handleChange = async (e) => {
      setForm({
        ...form,
        [e.target.name]: e.target.value
      })
    }
  
    const roleRedirect = (role) => {
      if(role === 'admin') {
        navigate('/admin')
      }else {
        navigate(-1)
      }
  
      }
  
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const res = await actionLogin(form)
      const role = res.data.payload.role
      console.log(role)
      roleRedirect(role)
      toast.success("Welcome back")
    } catch (err) {
      console.log(err)
      //const errMsg = err.response.data.message
     // toast.error(err)
      
    }  
   
  };

  return (
    <div
    className="min-h-screen flex 
  items-center justify-center bg-gray-100"
  >
    <div className="w-full shadow-md bg-white p-8 max-w-md">
    <h1 className="text-2xl text-center my-4 font-bold">Login</h1>
    <form onSubmit={handleSubmit} >
    <div className="space-y-4">        
      <input
        placeholder="Email"
      className='border w-full px-3 py-2 rounded
          focus:outline-none focus:ring-2 focus:ring-blue-500
          focus:border-transparent'
        onChange={handleChange}
        name='email'
        type='email'
      />

      <input 
         placeholder="Password"
        className='border w-full px-3 py-2 rounded
          focus:outline-none focus:ring-2 focus:ring-blue-500
          focus:border-transparent'
        onChange={handleChange}
        name='password'
        type='text'
      />


<button
            className="bg-blue-500 rounded-md
           w-full text-white font-bold py-2 shadow
           hover:bg-blue-700
           ">
            Login
          </button>
    </div>
    </form>
    </div>

  </div>
  )
}

export default authPosLogin