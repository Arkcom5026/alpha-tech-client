import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  FaMoneyBillWave,
  FaCashRegister,
  FaChartLine,
  FaFileInvoiceDollar,
  FaCreditCard,
  FaExchangeAlt,
  FaPiggyBank,
  FaCalculator,
  FaUserTie,
  FaBuilding,
  FaChartBar
} from 'react-icons/fa';
import { FaPlus } from 'react-icons/fa';

const SidebarFinance = () => {
  const location = useLocation();
  const currentPath = location.pathname.toLowerCase();
  const [openMenu, setOpenMenu] = useState(null);

  useEffect(() => {
    if (currentPath.includes('/pos/finance')) {
      if (currentPath.includes('transactions')) setOpenMenu('transactions');
      else if (currentPath.includes('invoices')) setOpenMenu('invoices');
      else if (currentPath.includes('accounts')) setOpenMenu('accounts');
      else if (currentPath.includes('reports')) setOpenMenu('reports');
      else setOpenMenu('dashboard');
    }
  }, [currentPath]);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const linkClass = ({ isActive }) =>
    isActive
      ? 'relative bg-gradient-to-r from-blue-600 to-blue-500 text-white font-medium rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out shadow-md hover:shadow-lg transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1.5 before:h-8 before:bg-white before:rounded-r-md'
      : 'relative bg-blue-50 text-blue-800 rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out hover:bg-gradient-to-r hover:from-blue-100 hover:to-blue-50 hover:text-blue-900 hover:shadow-md transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1 before:h-6 before:bg-transparent before:rounded-r-md hover:before:w-1.5 hover:before:h-8 hover:before:bg-blue-400';

  const menuButtonClass = "w-full text-left text-base text-white font-semibold px-3 py-2 rounded-lg transition-all duration-300 ease-in-out hover:bg-blue-600 hover:shadow-md flex items-center justify-between group";

  return (
    <div className="bg-gradient-to-b from-blue-600 to-blue-500 text-white w-64 h-screen flex flex-col shadow-xl">

      <div className="h-24 bg-blue-800 flex items-center justify-center text-2xl font-bold text-white shadow-md gap-2">
        <FaMoneyBillWave className="text-white text-3xl" />
        ระบบการเงิน
      </div>

      <div className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        {/* === หน้า finance (การเงิน) === */}
        {currentPath.includes('/pos/finance') && (
          <>
            {/* เมนูแดชบอร์ดการเงิน */}
            <NavLink to="/pos/finance" className={linkClass} end>
              <FaMoneyBillWave className="text-blue-600" />
              ภาพรวมการเงิน
            </NavLink>

            {/* เมนูธุรกรรมการเงิน */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('transactions')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaExchangeAlt className="text-blue-200 group-hover:text-white" />
                  ธุรกรรมการเงิน
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'transactions' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'transactions' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/finance/transactions" className={linkClass}>
                    <FaCashRegister className="text-blue-600" />
                    รายการธุรกรรม
                  </NavLink>
                  <NavLink to="/pos/finance/transactions/new" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    บันทึกธุรกรรม
                  </NavLink>
                  <NavLink to="/pos/finance/payments" className={linkClass}>
                    <FaCreditCard className="text-blue-600" />
                    การชำระเงิน
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูใบแจ้งหนี้/ใบเสร็จ */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('invoices')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaFileInvoiceDollar className="text-blue-200 group-hover:text-white" />
                  ใบแจ้งหนี้/ใบเสร็จ
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'invoices' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'invoices' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/finance/invoices" className={linkClass}>
                    <FaFileInvoiceDollar className="text-blue-600" />
                    ใบแจ้งหนี้ทั้งหมด
                  </NavLink>
                  <NavLink to="/pos/finance/receipts" className={linkClass}>
                    <FaFileInvoiceDollar className="text-blue-600" />
                    ใบเสร็จรับเงิน
                  </NavLink>
                  <NavLink to="/pos/finance/invoices/new" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    ออกใบแจ้งหนี้
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูบัญชี */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('accounts')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaPiggyBank className="text-blue-200 group-hover:text-white" />
                  บัญชีและการเงิน
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'accounts' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'accounts' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/finance/accounts" className={linkClass}>
                    <FaBuilding className="text-blue-600" />
                    บัญชีธนาคาร
                  </NavLink>
                  <NavLink to="/pos/finance/expenses" className={linkClass}>
                    <FaCalculator className="text-blue-600" />
                    รายจ่าย
                  </NavLink>
                  <NavLink to="/pos/finance/taxes" className={linkClass}>
                    <FaCalculator className="text-blue-600" />
                    ภาษี
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูรายงานการเงิน */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('reports')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaChartBar className="text-blue-200 group-hover:text-white" />
                  รายงานการเงิน
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'reports' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'reports' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/finance/reports/income" className={linkClass}>
                    <FaChartLine className="text-blue-600" />
                    รายงานรายได้
                  </NavLink>
                  <NavLink to="/pos/finance/reports/expenses" className={linkClass}>
                    <FaChartLine className="text-blue-600" />
                    รายงานรายจ่าย
                  </NavLink>
                  <NavLink to="/pos/finance/reports/profit-loss" className={linkClass}>
                    <FaChartLine className="text-blue-600" />
                    กำไร-ขาดทุน
                  </NavLink>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default SidebarFinance;