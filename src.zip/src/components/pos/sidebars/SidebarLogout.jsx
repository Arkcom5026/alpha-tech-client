import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  FaBoxOpen,
  FaPlus,
  FaUserTie,
  FaFileInvoice,
  FaMoneyCheckAlt,
  FaReceipt,
  FaChartBar,
  FaUserCircle,
  FaSignOutAlt,
  FaCogs,
  FaUsers,
  FaShoppingBasket,
  FaCashRegister,
  FaTags
} from 'react-icons/fa';

const SidebarLogout = () => {
  const location = useLocation();
  const currentPath = location.pathname.toLowerCase();
  const [openMenu, setOpenMenu] = useState(null);

  useEffect(() => {
    if (currentPath.includes('/pos/sales')) {
      if (currentPath.includes('customer')) setOpenMenu('customer');
      else if (currentPath.includes('transaction')) setOpenMenu('transaction');
      else if (currentPath.includes('report')) setOpenMenu('report');
      else setOpenMenu('sale');
    }
  }, [currentPath]);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const linkClass = ({ isActive }) =>
    isActive
      ? 'relative bg-gradient-to-r from-blue-600 to-blue-500 text-white font-medium rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out shadow-md hover:shadow-lg transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1.5 before:h-8 before:bg-white before:rounded-r-md'
      : 'relative bg-blue-50 text-blue-800 rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out hover:bg-gradient-to-r hover:from-blue-100 hover:to-blue-50 hover:text-blue-900 hover:shadow-md transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1 before:h-6 before:bg-transparent before:rounded-r-md hover:before:w-1.5 hover:before:h-8 hover:before:bg-blue-400';

  const menuButtonClass = "w-full text-left text-base text-white font-semibold px-3 py-2 rounded-lg transition-all duration-300 ease-in-out hover:bg-blue-600 hover:shadow-md flex items-center justify-between group";

  return (
    <div className="bg-gradient-to-b from-blue-600 to-blue-500 text-white w-64 h-screen flex flex-col shadow-xl">
      <div className="h-24 bg-blue-800 flex items-center justify-center text-2xl font-bold shadow-md">
        POS System
      </div>

      <div className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        {/* === หน้า sales (การขาย) === */}
        {currentPath.includes('/pos/sales') && (
          <>
            {/* เมนูการขาย */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('sale')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaShoppingBasket className="text-blue-200 group-hover:text-white" />
                  การขาย
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'sale' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              
              {openMenu === 'sale' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/sales/sales" className={linkClass}>
                    <FaCashRegister className="text-blue-600" />
                    จัดการการขาย
                  </NavLink>

                  <NavLink to="/pos/sales/products" className={linkClass}>
                    <FaTags className="text-blue-600" />
                    สินค้าขายดี
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูลูกค้า */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('customer')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaUserTie className="text-blue-200 group-hover:text-white" />
                  ลูกค้า
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'customer' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {openMenu === 'customer' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/sales/customers" className={linkClass}>
                    <FaUserTie className="text-blue-600" />
                    ทะเบียนลูกค้า
                  </NavLink>
                  <NavLink to="/pos/sales/customers/new" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    ลงทะเบียนลูกค้าใหม่
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูรายงาน */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('report')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaChartBar className="text-blue-200 group-hover:text-white" />
                  รายงาน
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'report' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {openMenu === 'report' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/sales/sales-reports" className={linkClass}>
                    <FaChartBar className="text-blue-600" />
                    รายงานการขาย
                  </NavLink>
                </div>
              )}
            </div>
          </>
        )}

        {/* ส่วนอื่นๆ ที่เหลือเหมือนเดิม */}
        {/* ... */}
      </div>
    </div>
  );
};

export default SidebarLogout;