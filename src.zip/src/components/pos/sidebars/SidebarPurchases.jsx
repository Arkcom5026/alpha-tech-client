import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  FaShoppingCart, FaFileInvoiceDollar, FaBoxes, FaWarehouse, FaClipboardList, FaClipboardCheck,
  FaHistory, FaCog, FaHome, FaSearch, FaFileExport, FaFileAlt, FaBell, FaStore, FaPlus, FaTruck,
  FaReceipt, FaBalanceScale, FaChartBar, FaCalendarAlt, FaChartLine, FaUserTie, FaUsers, FaPercent,
  FaTimes, FaCheck, FaClock, FaExchangeAlt, FaMoneyBillWave, FaBolt, FaTags
} from 'react-icons/fa';

const SidebarPurchases = () => {
  const location = useLocation();
  const currentPath = location.pathname.toLowerCase();
  const [openMenu, setOpenMenu] = useState(null);

  useEffect(() => {
    if (currentPath.includes('/pos/purchase')) {
      if (currentPath.includes('requisitions')) setOpenMenu('requisitions');
      else if (currentPath.includes('orders')) setOpenMenu('orders');
      else if (currentPath.includes('suppliers')) setOpenMenu('suppliers');
      else if (currentPath.includes('inventory')) setOpenMenu('inventory');
      else if (currentPath.includes('receiving')) setOpenMenu('receiving');
      else if (currentPath.includes('reports')) setOpenMenu('reports');
      else setOpenMenu('dashboard');
    }
  }, [currentPath]);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const linkClass = ({ isActive }) =>
    isActive
      ? 'relative bg-blue-50 text-blue-800 rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out hover:bg-gradient-to-r hover:from-blue-100 hover:to-blue-50 hover:text-blue-900 hover:shadow-md transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1 before:h-6 before:bg-transparent before:rounded-r-md hover:before:w-1.5 hover:before:h-8 hover:before:bg-blue-400'
      : 'relative bg-gradient-to-r from-blue-600 to-blue-500 text-white font-medium rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out shadow-md hover:shadow-lg transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1.5 before:h-8 before:bg-white before:rounded-r-md'

  const menuButtonClass = "w-full text-left text-base text-white font-semibold px-3 py-2 rounded-lg transition-all duration-300 ease-in-out hover:bg-blue-600 hover:shadow-md flex items-center justify-between group";

  return (
    <div className="bg-gradient-to-b from-blue-700 to-blue-600 text-white w-64 h-screen flex flex-col shadow-xl">
      <div className="h-24 bg-blue-800 flex items-center justify-center text-2xl font-bold shadow-md">
        <FaShoppingCart className="mr-2" />
        ระบบจัดซื้อ
      </div>

      <div className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        {currentPath.includes('/pos/purchase') && (
          <>
            <NavLink to="/pos/purchases" className={linkClass} end>
              <FaHome className="text-blue-600" />
              ภาพรวมการจัดซื้อ
            </NavLink>


            {/* Purchase Orders */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('orders')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaFileAlt className="text-blue-200 group-hover:text-white" />
                  ใบสั่งซื้อ
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'orders' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'orders' && (
                <div className="pl-2 mt-1 space-y-1">

                  <NavLink to="/pos/purchases/orders/purchaseorder" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    สร้างใบสั่งซื้อใหม่
                  </NavLink>
                  <NavLink to="/pos/purchases/orders/listpurchaseorder" className={linkClass}>
                    <FaClipboardList className="text-blue-600" />
                    รายการใบสั่งซื้อ
                  </NavLink>
                  <NavLink to="/pos/purchases/orders/pending" className={linkClass}>
                    <FaClock className="text-blue-600" />
                    รอดำเนินการ
                  </NavLink>
                  <NavLink to="/pos/purchases/orders/completed" className={linkClass}>
                    <FaCheck className="text-blue-600" />
                    เสร็จสมบูรณ์
                  </NavLink>
                </div>
              )}
            </div>

            {/* Supplier Management */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('suppliers')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaUserTie className="text-blue-200 group-hover:text-white" />
                  จัดการผู้ขาย
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'suppliers' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'suppliers' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/purchases/suppliers/listsuppliers" className={linkClass}>
                    <FaUsers className="text-blue-600" />
                    รายชื่อผู้ขาย
                  </NavLink>
                  <NavLink to="/pos/purchases/suppliers/addsupplier" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    เพิ่มผู้ขายใหม่
                  </NavLink>
                  <NavLink to="/pos/purchases/suppliers/performance" className={linkClass}>
                    <FaChartLine className="text-blue-600" />
                    ประสิทธิภาพผู้ขาย
                  </NavLink>
                  <NavLink to="/pos/purchases/suppliers/contracts" className={linkClass}>
                    <FaFileAlt className="text-blue-600" />
                    สัญญาซื้อขาย
                  </NavLink>
                </div>
              )}
            </div>

            {/* Inventory Management */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('inventory')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaWarehouse className="text-blue-200 group-hover:text-white" />
                  จัดการสินค้าคงคลัง
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'inventory' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'inventory' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/purchases/inventory/items" className={linkClass}>
                    <FaBoxes className="text-blue-600" />
                    รายการสินค้า
                  </NavLink>
                  <NavLink to="/pos/purchases/inventory/levels" className={linkClass}>
                    <FaClipboardList className="text-blue-600" />
                    ระดับสินค้าคงคลัง
                  </NavLink>
                  <NavLink to="/pos/purchases/inventory/reorder" className={linkClass}>
                    <FaBell className="text-blue-600" />
                    จุดสั่งซื้อใหม่
                  </NavLink>
                  <NavLink to="/pos/purchases/inventory/categories" className={linkClass}>
                    <FaTags className="text-blue-600" />
                    หมวดหมู่สินค้า
                  </NavLink>
                </div>
              )}
            </div>

            {/* Goods Receiving */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('receiving')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaTruck className="text-blue-200 group-hover:text-white" />
                  การรับสินค้า
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'receiving' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'receiving' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/purchases/receiving/new" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    รับสินค้าใหม่
                  </NavLink>
                  <NavLink to="/pos/purchases/receiving/list" className={linkClass}>
                    <FaClipboardList className="text-blue-600" />
                    รายการรับสินค้า
                  </NavLink>
                  <NavLink to="/pos/purchases/receiving/inspection" className={linkClass}>
                    <FaSearch className="text-blue-600" />
                    ตรวจสอบคุณภาพ
                  </NavLink>
                  <NavLink to="/pos/purchases/receiving/returns" className={linkClass}>
                    <FaExchangeAlt className="text-blue-600" />
                    ส่งคืนสินค้า
                  </NavLink>
                </div>
              )}
            </div>

            {/* Invoices & Payments */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('invoices')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaFileInvoiceDollar className="text-blue-200 group-hover:text-white" />
                  ใบแจ้งหนี้และการชำระเงิน
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'invoices' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'invoices' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/purchases/invoices/list" className={linkClass}>
                    <FaFileInvoiceDollar className="text-blue-600" />
                    ใบแจ้งหนี้
                  </NavLink>
                  <NavLink to="/pos/purchases/invoices/payments" className={linkClass}>
                    <FaMoneyBillWave className="text-blue-600" />
                    การชำระเงิน
                  </NavLink>
                  <NavLink to="/pos/purchases/invoices/credit" className={linkClass}>
                    <FaReceipt className="text-blue-600" />
                    ใบเครดิต
                  </NavLink>
                  <NavLink to="/pos/purchases/invoices/matching" className={linkClass}>
                    <FaBalanceScale className="text-blue-600" />
                    การจับคู่ 3 ทาง
                  </NavLink>
                </div>
              )}
            </div>

            {/* Reports */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('reports')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaChartBar className="text-blue-200 group-hover:text-white" />
                  รายงานการจัดซื้อ
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'reports' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'reports' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/purchases/reports/spending" className={linkClass}>
                    <FaMoneyBillWave className="text-blue-600" />
                    รายงานการใช้จ่าย
                  </NavLink>
                  <NavLink to="/pos/purchases/reports/suppliers" className={linkClass}>
                    <FaUserTie className="text-blue-600" />
                    รายงานผู้ขาย
                  </NavLink>
                  <NavLink to="/pos/purchases/reports/inventory" className={linkClass}>
                    <FaWarehouse className="text-blue-600" />
                    รายงานสินค้าคงคลัง
                  </NavLink>
                  <NavLink to="/pos/purchases/reports/export" className={linkClass}>
                    <FaFileExport className="text-blue-600" />
                    ส่งออกรายงาน
                  </NavLink>
                </div>
              )}
            </div>

            {/* Quick Access */}
            <div className="pt-4">
              <h3 className="text-xs uppercase text-blue-200 font-semibold px-3 py-2">การเข้าถึงอย่างรวดเร็ว</h3>
              <NavLink to="/pos/purchase/quick-order" className={linkClass}>
                <FaBolt className="text-blue-600" />
                สั่งซื้อด่วน
              </NavLink>
              <NavLink to="/pos/purchases/search" className={linkClass}>
                <FaSearch className="text-blue-600" />
                ค้นหาใบสั่งซื้อ
              </NavLink>
              <NavLink to="/pos/purchases/notifications" className={linkClass}>
                <FaBell className="text-blue-600" />
                การแจ้งเตือน
              </NavLink>
            </div>

            {/* Settings */}
            <NavLink to="/pos/purchases/settings" className={linkClass}>
              <FaCog className="text-blue-600" />
              ตั้งค่าระบบจัดซื้อ
            </NavLink>
          </>
        )}
      </div>
    </div>
  );
};

export default SidebarPurchases;