import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  FaChartBar,
  FaChartLine,
  FaChartPie,
  FaFileExcel,
  FaFilePdf,
  FaPrint,
  FaMoneyBillWave,
  FaShoppingCart,
  FaBoxes,
  FaUsers,
  FaCalendarAlt
} from 'react-icons/fa';

const SidebarReports = () => {
  const location = useLocation();
  const currentPath = location.pathname.toLowerCase();
  const [openMenu, setOpenMenu] = useState(null);

  useEffect(() => {
    if (currentPath.includes('/pos/reports')) {
      if (currentPath.includes('sales')) setOpenMenu('sales');
      else if (currentPath.includes('inventory')) setOpenMenu('inventory');
      else if (currentPath.includes('financial')) setOpenMenu('financial');
      else if (currentPath.includes('customer')) setOpenMenu('customer');
      else setOpenMenu('dashboard');
    }
  }, [currentPath]);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const linkClass = ({ isActive }) =>
    isActive
      ? 'relative bg-gradient-to-r from-blue-600 to-blue-500 text-white font-medium rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out shadow-md hover:shadow-lg transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1.5 before:h-8 before:bg-white before:rounded-r-md'
      : 'relative bg-blue-50 text-blue-800 rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out hover:bg-gradient-to-r hover:from-blue-100 hover:to-blue-50 hover:text-blue-900 hover:shadow-md transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1 before:h-6 before:bg-transparent before:rounded-r-md hover:before:w-1.5 hover:before:h-8 hover:before:bg-blue-400';

  const menuButtonClass = "w-full text-left text-base text-white font-semibold px-3 py-2 rounded-lg transition-all duration-300 ease-in-out hover:bg-blue-600 hover:shadow-md flex items-center justify-between group";

  return (
    <div className="bg-gradient-to-b from-blue-600 to-blue-500 text-white w-64 h-screen flex flex-col shadow-xl">
      <div className="h-24 bg-blue-800 flex items-center justify-center text-2xl font-bold text-white shadow-md gap-2">
        <FaChartBar className="text-white text-3xl" />
        ระบบรายงาน
      </div>

      <div className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        {/* === หน้า reports (รายงาน) === */}
        {currentPath.includes('/pos/reports') && (
          <>
            {/* เมนูแดชบอร์ดรายงาน */}
            <NavLink to="/pos/reports" className={linkClass} end>
              <FaChartBar className="text-blue-600" />
              ภาพรวมรายงาน
            </NavLink>

            {/* เมนูรายงานการขาย */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('sales')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaShoppingCart className="text-blue-200 group-hover:text-white" />
                  รายงานการขาย
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'sales' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'sales' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/reports/sales/daily" className={linkClass}>
                    <FaCalendarAlt className="text-blue-600" />
                    รายงานประจำวัน
                  </NavLink>
                  <NavLink to="/pos/reports/sales/monthly" className={linkClass}>
                    <FaChartLine className="text-blue-600" />
                    รายงานประจำเดือน
                  </NavLink>
                  <NavLink to="/pos/reports/sales/products" className={linkClass}>
                    <FaBoxes className="text-blue-600" />
                    สินค้าขายดี
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูรายงานสต๊อก */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('inventory')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaBoxes className="text-blue-200 group-hover:text-white" />
                  รายงานสต๊อก
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'inventory' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'inventory' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/reports/inventory/status" className={linkClass}>
                    <FaClipboardList className="text-blue-600" />
                    สถานะสินค้าคงคลัง
                  </NavLink>
                  <NavLink to="/pos/reports/inventory/movement" className={linkClass}>
                    <FaExchangeAlt className="text-blue-600" />
                    การเคลื่อนไหวสินค้า
                  </NavLink>
                  <NavLink to="/pos/reports/inventory/low" className={linkClass}>
                    <FaExclamationTriangle className="text-blue-600" />
                    สินค้าหมด/ใกล้หมด
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูรายงานการเงิน */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('financial')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaMoneyBillWave className="text-blue-200 group-hover:text-white" />
                  รายงานการเงิน
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'financial' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'financial' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/reports/financial/income" className={linkClass}>
                    <FaChartLine className="text-blue-600" />
                    รายงานรายได้
                  </NavLink>
                  <NavLink to="/pos/reports/financial/expenses" className={linkClass}>
                    <FaChartLine className="text-blue-600" />
                    รายงานรายจ่าย
                  </NavLink>
                  <NavLink to="/pos/reports/financial/profit" className={linkClass}>
                    <FaChartPie className="text-blue-600" />
                    กำไร-ขาดทุน
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูรายงานลูกค้า */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('customer')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaUsers className="text-blue-200 group-hover:text-white" />
                  รายงานลูกค้า
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'customer' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'customer' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/reports/customer/activity" className={linkClass}>
                    <FaChartLine className="text-blue-600" />
                    พฤติกรรมลูกค้า
                  </NavLink>
                  <NavLink to="/pos/reports/customer/loyalty" className={linkClass}>
                    <FaUsers className="text-blue-600" />
                    ลูกค้าประจำ
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูเครื่องมือรายงาน */}
            <div className="space-y-1 pt-4">
              <NavLink to="/pos/reports/export/excel" className={linkClass}>
                <FaFileExcel className="text-blue-600" />
                ส่งออก Excel
              </NavLink>
              <NavLink to="/pos/reports/export/pdf" className={linkClass}>
                <FaFilePdf className="text-blue-600" />
                ส่งออก PDF
              </NavLink>
              <NavLink to="/pos/reports/print" className={linkClass}>
                <FaPrint className="text-blue-600" />
                พิมพ์รายงาน
              </NavLink>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default SidebarReports;