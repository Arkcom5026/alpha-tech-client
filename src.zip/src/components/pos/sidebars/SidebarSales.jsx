import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  FaShoppingCart,
  FaUserTie,
  FaUsers,
  FaChartBar,
  FaFileInvoiceDollar,
  FaMoneyBillWave,
  FaBoxes,
  FaTags,
  FaPercent,
  FaExchangeAlt,
  FaHistory,
  FaCog,
  FaHome,
  FaSearch,
  FaFileExport,
  FaFileAlt,
  FaBell,
  FaStore,
  FaPlus,
  FaClipboardList,
  FaClipboardCheck,
  FaWarehouse,
  FaStar,
  FaCalendarAlt,
  FaChartLine,
  FaBolt
} from 'react-icons/fa';


const SidebarSales = () => {
  const location = useLocation();
  const currentPath = location.pathname.toLowerCase();
  const [openMenu, setOpenMenu] = useState(null);

  useEffect(() => {
    if (currentPath.includes('/pos/sales')) {
      if (currentPath.includes('orders')) setOpenMenu('orders');
      else if (currentPath.includes('customers')) setOpenMenu('customers');
      else if (currentPath.includes('products')) setOpenMenu('products');
      else if (currentPath.includes('promotions')) setOpenMenu('promotions');
      else if (currentPath.includes('transactions')) setOpenMenu('transactions');
      else if (currentPath.includes('reports')) setOpenMenu('reports');
      else setOpenMenu('dashboard');
    }
  }, [currentPath]);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const linkClass = ({ isActive }) =>
    isActive
      ? 'relative bg-gradient-to-r from-blue-600 to-blue-500 text-white font-medium rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out shadow-md hover:shadow-lg transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1.5 before:h-8 before:bg-white before:rounded-r-md'
      : 'relative bg-blue-50 text-blue-800 rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out hover:bg-gradient-to-r hover:from-blue-100 hover:to-blue-50 hover:text-blue-900 hover:shadow-md transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1 before:h-6 before:bg-transparent before:rounded-r-md hover:before:w-1.5 hover:before:h-8 hover:before:bg-blue-400';

  const menuButtonClass = "w-full text-left text-base text-white font-semibold px-3 py-2 rounded-lg transition-all duration-300 ease-in-out hover:bg-blue-600 hover:shadow-md flex items-center justify-between group";

  return (
    <div className="bg-gradient-to-b from-blue-700 to-blue-600 text-white w-64 h-screen flex flex-col shadow-xl">
      <div className="h-24 bg-blue-800 flex items-center justify-center text-2xl font-bold shadow-md">
        <FaStore className="mr-2" />
        ระบบการขาย
      </div>

      <div className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        {currentPath.includes('/pos/sales') && (
          <>
            {/* Dashboard */}
            <NavLink to="/pos/sales" className={linkClass} end>
              <FaHome className="text-blue-600" />
              ภาพรวมการขาย
            </NavLink>

            {/* Sales Orders */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('orders')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaShoppingCart className="text-blue-200 group-hover:text-white" />
                  การขายและออเดอร์
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'orders' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'orders' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/sales/orders/new" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    สร้างออเดอร์ใหม่
                  </NavLink>
                  <NavLink to="/pos/sales/orders/pos" className={linkClass}>
                    <FaShoppingCart className="text-blue-600" />
                    จุดขาย (POS)
                  </NavLink>
                  <NavLink to="/pos/sales/orders/list" className={linkClass}>
                    <FaClipboardList className="text-blue-600" />
                    รายการออเดอร์
                  </NavLink>
                  <NavLink to="/pos/sales/orders/pending" className={linkClass}>
                    <FaHistory className="text-blue-600" />
                    ออเดอร์ที่รอดำเนินการ
                  </NavLink>
                  <NavLink to="/pos/sales/orders/completed" className={linkClass}>
                    <FaClipboardCheck className="text-blue-600" />
                    ออเดอร์ที่เสร็จสมบูรณ์
                  </NavLink>
                </div>
              )}
            </div>

            {/* Customer Management */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('customers')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaUsers className="text-blue-200 group-hover:text-white" />
                  จัดการลูกค้า
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'customers' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'customers' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/sales/customers/list" className={linkClass}>
                    <FaUsers className="text-blue-600" />
                    รายชื่อลูกค้า
                  </NavLink>
                  <NavLink to="/pos/sales/customers/new" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    เพิ่มลูกค้าใหม่
                  </NavLink>
                  <NavLink to="/pos/sales/customers/segments" className={linkClass}>
                    <FaUserTie className="text-blue-600" />
                    กลุ่มลูกค้า
                  </NavLink>
                  <NavLink to="/pos/sales/customers/history" className={linkClass}>
                    <FaHistory className="text-blue-600" />
                    ประวัติการซื้อ
                  </NavLink>
                </div>
              )}
            </div>

            {/* Product Management */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('products')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaBoxes className="text-blue-200 group-hover:text-white" />
                  จัดการสินค้า
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'products' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'products' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/sales/products/list" className={linkClass}>
                    <FaBoxes className="text-blue-600" />
                    รายการสินค้า
                  </NavLink>
                  <NavLink to="/pos/sales/products/categories" className={linkClass}>
                    <FaTags className="text-blue-600" />
                    หมวดหมู่สินค้า
                  </NavLink>
                  <NavLink to="/pos/sales/products/inventory" className={linkClass}>
                    <FaWarehouse className="text-blue-600" />
                    สต็อกสินค้า
                  </NavLink>
                  <NavLink to="/pos/sales/products/price-lists" className={linkClass}>
                    <FaMoneyBillWave className="text-blue-600" />
                    ราคาสินค้า
                  </NavLink>
                </div>
              )}
            </div>

            {/* Promotions */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('promotions')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaPercent className="text-blue-200 group-hover:text-white" />
                  โปรโมชั่นและส่วนลด
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'promotions' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'promotions' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/sales/promotions/discounts" className={linkClass}>
                    <FaTags className="text-blue-600" />
                    ส่วนลดสินค้า
                  </NavLink>
                  <NavLink to="/pos/sales/promotions/coupons" className={linkClass}>
                    <FaPercent className="text-blue-600" />
                    คูปองส่วนลด
                  </NavLink>
                  <NavLink to="/pos/sales/promotions/bundles" className={linkClass}>
                    <FaBoxes className="text-blue-600" />
                    ชุดโปรโมชั่น
                  </NavLink>
                  <NavLink to="/pos/sales/promotions/loyalty" className={linkClass}>
                    <FaStar className="text-blue-600" />
                    โปรแกรมสะสมแต้ม
                  </NavLink>
                </div>
              )}
            </div>

            {/* Transactions */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('transactions')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaExchangeAlt className="text-blue-200 group-hover:text-white" />
                  การทำธุรกรรม
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'transactions' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'transactions' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/sales/transactions/invoices" className={linkClass}>
                    <FaFileInvoiceDollar className="text-blue-600" />
                    ใบแจ้งหนี้
                  </NavLink>
                  <NavLink to="/pos/sales/transactions/receipts" className={linkClass}>
                    <FaFileAlt className="text-blue-600" />
                    ใบเสร็จรับเงิน
                  </NavLink>
                  <NavLink to="/pos/sales/transactions/payments" className={linkClass}>
                    <FaMoneyBillWave className="text-blue-600" />
                    การชำระเงิน
                  </NavLink>
                  <NavLink to="/pos/sales/transactions/returns" className={linkClass}>
                    <FaExchangeAlt className="text-blue-600" />
                    คืนสินค้า
                  </NavLink>
                </div>
              )}
            </div>

            {/* Reports */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('reports')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaChartBar className="text-blue-200 group-hover:text-white" />
                  รายงานการขาย
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'reports' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'reports' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/sales/reports/daily" className={linkClass}>
                    <FaCalendarAlt className="text-blue-600" />
                    รายงานประจำวัน
                  </NavLink>
                  <NavLink to="/pos/sales/reports/sales" className={linkClass}>
                    <FaChartLine className="text-blue-600" />
                    รายงานยอดขาย
                  </NavLink>
                  <NavLink to="/pos/sales/reports/products" className={linkClass}>
                    <FaBoxes className="text-blue-600" />
                    รายงานสินค้า
                  </NavLink>
                  <NavLink to="/pos/sales/reports/customers" className={linkClass}>
                    <FaUsers className="text-blue-600" />
                    รายงานลูกค้า
                  </NavLink>
                  <NavLink to="/pos/sales/reports/export" className={linkClass}>
                    <FaFileExport className="text-blue-600" />
                    ส่งออกรายงาน
                  </NavLink>
                </div>
              )}
            </div>

            {/* Quick Access */}
            <div className="pt-4">
              <h3 className="text-xs uppercase text-blue-200 font-semibold px-3 py-2">การเข้าถึงอย่างรวดเร็ว</h3>
              <NavLink to="/pos/sales/quick-sale" className={linkClass}>
                <FaBolt className="text-blue-600" />
                ขายด่วน
              </NavLink>
              <NavLink to="/pos/sales/search" className={linkClass}>
                <FaSearch className="text-blue-600" />
                ค้นหาออเดอร์
              </NavLink>
              <NavLink to="/pos/sales/notifications" className={linkClass}>
                <FaBell className="text-blue-600" />
                การแจ้งเตือน
              </NavLink>
            </div>

            {/* Settings */}
            <NavLink to="/pos/sales/settings" className={linkClass}>
              <FaCog className="text-blue-600" />
              ตั้งค่าระบบขาย
            </NavLink>
          </>
        )}
      </div>
    </div>
  );
};

export default SidebarSales;