import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  FaTools,
  FaWrench,
  FaUserCog,
  FaCalendarAlt,
  FaClipboardList,
  FaChartLine,
  FaPlus,
  FaBoxes,
  FaFileInvoiceDollar,
  FaMoneyBillWave,
  FaTruck,
  FaWarehouse,
  FaClipboardCheck,
  FaHistory,
  FaCogs,
  FaFileAlt,
  FaFileExport
} from 'react-icons/fa';

const SidebarServices = () => {
  const location = useLocation();
  const currentPath = location.pathname.toLowerCase();
  const [openMenu, setOpenMenu] = useState(null);

  useEffect(() => {
    if (currentPath.includes('/pos/services')) {
      if (currentPath.includes('repair')) setOpenMenu('repair');
      else if (currentPath.includes('customer')) setOpenMenu('customer');
      else if (currentPath.includes('appointment')) setOpenMenu('appointment');
      else if (currentPath.includes('inventory')) setOpenMenu('inventory');
      else if (currentPath.includes('billing')) setOpenMenu('billing');
      else if (currentPath.includes('report')) setOpenMenu('report');
      else setOpenMenu('dashboard');
    }
  }, [currentPath]);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const linkClass = ({ isActive }) =>
    isActive
      ? 'relative bg-gradient-to-r from-blue-600 to-blue-500 text-white font-medium rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out shadow-md hover:shadow-lg transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1.5 before:h-8 before:bg-white before:rounded-r-md'
      : 'relative bg-blue-50 text-blue-800 rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out hover:bg-gradient-to-r hover:from-blue-100 hover:to-blue-50 hover:text-blue-900 hover:shadow-md transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1 before:h-6 before:bg-transparent before:rounded-r-md hover:before:w-1.5 hover:before:h-8 hover:before:bg-blue-400';

  const menuButtonClass = "w-full text-left text-base text-white font-semibold px-3 py-2 rounded-lg transition-all duration-300 ease-in-out hover:bg-blue-600 hover:shadow-md flex items-center justify-between group";

  return (
    <div className="bg-gradient-to-b from-blue-600 to-blue-500 text-white w-64 h-screen flex flex-col shadow-xl">
      
      <div className="h-24 bg-blue-800 flex items-center justify-center text-2xl font-bold text-white shadow-md gap-2">
        <FaTools className="text-white text-3xl" />
        Service Center
      </div>

      <div className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        {currentPath.includes('/pos/services') && (
          <>
            {/* Dashboard */}
            <NavLink to="/pos/services" className={linkClass} end>
              <FaClipboardCheck className="text-blue-600" />
              ภาพรวมบริการ
            </NavLink>

            {/* Repair Management */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('repair')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaTools className="text-blue-200 group-hover:text-white" />
                  จัดการงานซ่อม
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'repair' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'repair' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/services/repairs/new" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    รับงานซ่อมใหม่
                  </NavLink>
                  <NavLink to="/pos/services/repairs/queue" className={linkClass}>
                    <FaClipboardList className="text-blue-600" />
                    คิวงานซ่อม
                  </NavLink>
                  <NavLink to="/pos/services/repairs/in-progress" className={linkClass}>
                    <FaWrench className="text-blue-600" />
                    งานที่กำลังดำเนินการ
                  </NavLink>
                  <NavLink to="/pos/services/repairs/completed" className={linkClass}>
                    <FaClipboardCheck className="text-blue-600" />
                    งานที่เสร็จแล้ว
                  </NavLink>
                </div>
              )}
            </div>

            {/* Customer Management */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('customer')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaUserCog className="text-blue-200 group-hover:text-white" />
                  จัดการลูกค้า
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'customer' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'customer' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/services/customers" className={linkClass}>
                    <FaUsers className="text-blue-600" />
                    รายชื่อลูกค้า
                  </NavLink>
                  <NavLink to="/pos/services/customers/new" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    ลูกค้าใหม่
                  </NavLink>
                  <NavLink to="/pos/services/customers/history" className={linkClass}>
                    <FaHistory className="text-blue-600" />
                    ประวัติลูกค้า
                  </NavLink>
                </div>
              )}
            </div>

            {/* Appointment System */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('appointment')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaCalendarAlt className="text-blue-200 group-hover:text-white" />
                  ระบบนัดหมาย
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'appointment' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'appointment' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/services/appointments" className={linkClass}>
                    <FaCalendarAlt className="text-blue-600" />
                    ตารางนัดหมาย
                  </NavLink>
                  <NavLink to="/pos/services/appointments/new" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    จัดการนัดหมายใหม่
                  </NavLink>
                  <NavLink to="/pos/services/appointments/calendar" className={linkClass}>
                    <FaCalendarAlt className="text-blue-600" />
                    ปฏิทินนัดหมาย
                  </NavLink>
                </div>
              )}
            </div>

            {/* Service Inventory */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('inventory')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaBoxes className="text-blue-200 group-hover:text-white" />
                  สินค้าและอะไหล่
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'inventory' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'inventory' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/services/inventory/parts" className={linkClass}>
                    <FaWrench className="text-blue-600" />
                    จัดการอะไหล่
                  </NavLink>
                  <NavLink to="/pos/services/inventory/supplies" className={linkClass}>
                    <FaBoxes className="text-blue-600" />
                    วัสดุสิ้นเปลือง
                  </NavLink>
                  <NavLink to="/pos/services/inventory/orders" className={linkClass}>
                    <FaTruck className="text-blue-600" />
                    สั่งซื้ออะไหล่
                  </NavLink>
                </div>
              )}
            </div>

            {/* Billing and Invoices */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('billing')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaFileInvoiceDollar className="text-blue-200 group-hover:text-white" />
                  การเงินบริการ
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'billing' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'billing' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/services/billing/invoices" className={linkClass}>
                    <FaFileInvoiceDollar className="text-blue-600" />
                    ใบแจ้งหนี้
                  </NavLink>
                  <NavLink to="/pos/services/billing/quotes" className={linkClass}>
                    <FaFileAlt className="text-blue-600" />
                    ใบเสนอราคา
                  </NavLink>
                  <NavLink to="/pos/services/billing/payments" className={linkClass}>
                    <FaMoneyBillWave className="text-blue-600" />
                    การชำระเงิน
                  </NavLink>
                </div>
              )}
            </div>

            {/* Reports */}
            <div className="space-y-1">
              <button onClick={() => toggleMenu('report')} className={menuButtonClass}>
                <span className="flex items-center gap-2">
                  <FaChartLine className="text-blue-200 group-hover:text-white" />
                  รายงานบริการ
                </span>
                <svg className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'report' ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'report' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/services/reports/service" className={linkClass}>
                    <FaTools className="text-blue-600" />
                    รายงานงานซ่อม
                  </NavLink>
                  <NavLink to="/pos/services/reports/performance" className={linkClass}>
                    <FaChartLine className="text-blue-600" />
                    ประสิทธิภาพการทำงาน
                  </NavLink>
                  <NavLink to="/pos/services/reports/export" className={linkClass}>
                    <FaFileExport className="text-blue-600" />
                    ส่งออกรายงาน
                  </NavLink>
                </div>
              )}
            </div>

            {/* Settings */}
            <NavLink to="/pos/services/settings" className={linkClass}>
              <FaCogs className="text-blue-600" />
              ตั้งค่าระบบ
            </NavLink>
          </>
        )}
      </div>
    </div>
  );
};

export default SidebarServices;