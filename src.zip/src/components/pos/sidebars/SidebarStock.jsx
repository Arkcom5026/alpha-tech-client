import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  FaBoxes,
  FaBoxOpen,
  FaWarehouse,
  FaClipboardList,
  FaChartBar,
  FaPlus,
  FaSearch,
  FaExchangeAlt,
  FaExclamationTriangle,
  FaTags,
  FaBarcode
} from 'react-icons/fa';

const SidebarStock = () => {
  const location = useLocation();
  const currentPath = location.pathname.toLowerCase();
  const [openMenu, setOpenMenu] = useState(null);

  useEffect(() => {
    if (currentPath.includes('/pos/stock')) {
      if (currentPath.includes('items')) setOpenMenu('items');
      else if (currentPath.includes('categories')) setOpenMenu('categories');
      else if (currentPath.includes('transactions')) setOpenMenu('transactions');
      else if (currentPath.includes('reports')) setOpenMenu('reports');
      else setOpenMenu('dashboard');
    }
  }, [currentPath]);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const linkClass = ({ isActive }) =>
    isActive
      ? 'relative bg-gradient-to-r from-blue-600 to-blue-500 text-white font-medium rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out shadow-md hover:shadow-lg transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1.5 before:h-8 before:bg-white before:rounded-r-md'
      : 'relative bg-blue-50 text-blue-800 rounded-lg px-4 py-2.5 flex items-center gap-3 transition-all duration-300 ease-in-out hover:bg-gradient-to-r hover:from-blue-100 hover:to-blue-50 hover:text-blue-900 hover:shadow-md transform hover:-translate-y-0.5 before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2 before:w-1 before:h-6 before:bg-transparent before:rounded-r-md hover:before:w-1.5 hover:before:h-8 hover:before:bg-blue-400';

  const menuButtonClass = "w-full text-left text-base text-white font-semibold px-3 py-2 rounded-lg transition-all duration-300 ease-in-out hover:bg-blue-600 hover:shadow-md flex items-center justify-between group";

  return (
    <div className="bg-gradient-to-b from-blue-600 to-blue-500 text-white w-64 h-screen flex flex-col shadow-xl">
      <div className="h-24 bg-blue-800 flex items-center justify-center text-2xl font-bold text-white shadow-md gap-2">
        <FaBoxes className="text-white text-3xl" />
        ระบบสต๊อกสินค้า
      </div>

      <div className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        {/* === หน้า stock (สต๊อกสินค้า) === */}
        {currentPath.includes('/pos/stock') && (
          <>
            {/* เมนูแดชบอร์ดสต๊อก */}
            <NavLink to="/pos/stock" className={linkClass} end>
              <FaBoxes className="text-blue-600" />
              ภาพรวมสต๊อก
            </NavLink>

            {/* เมนูสินค้า */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('items')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaBoxOpen className="text-blue-200 group-hover:text-white" />
                  สินค้า
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'items' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'items' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/stock/items" className={linkClass}>
                    <FaSearch className="text-blue-600" />
                    รายการสินค้าทั้งหมด
                  </NavLink>
                  
                  <NavLink to="features/product/pages/CreateProductPagePOS" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    เพิ่มสินค้าใหม่
                  </NavLink>
                  <NavLink to="/pos/stock/items/low" className={linkClass}>
                    <FaExclamationTriangle className="text-blue-600" />
                    สินค้าหมด/ใกล้หมด
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูหมวดหมู่ */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('categories')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaTags className="text-blue-200 group-hover:text-white" />
                  หมวดหมู่
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'categories' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'categories' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/stock/categories" className={linkClass}>
                    <FaTags className="text-blue-600" />
                    หมวดหมู่ทั้งหมด
                  </NavLink>
                  <NavLink to="/pos/stock/categories/new" className={linkClass}>
                    <FaPlus className="text-blue-600" />
                    เพิ่มหมวดหมู่
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูคลังสินค้า */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('warehouse')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaWarehouse className="text-blue-200 group-hover:text-white" />
                  คลังสินค้า
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'warehouse' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'warehouse' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/stock/warehouses" className={linkClass}>
                    <FaWarehouse className="text-blue-600" />
                    จัดการคลังสินค้า
                  </NavLink>
                  <NavLink to="/pos/stock/locations" className={linkClass}>
                    <FaBarcode className="text-blue-600" />
                    ตำแหน่งจัดเก็บ
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูธุรกรรมสต๊อก */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('transactions')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaExchangeAlt className="text-blue-200 group-hover:text-white" />
                  ธุรกรรมสต๊อก
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'transactions' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'transactions' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/stock/transfers" className={linkClass}>
                    <FaExchangeAlt className="text-blue-600" />
                    โอนย้ายสินค้า
                  </NavLink>
                  <NavLink to="/pos/stock/adjustments" className={linkClass}>
                    <FaClipboardList className="text-blue-600" />
                    ปรับยอดสต๊อก
                  </NavLink>
                </div>
              )}
            </div>

            {/* เมนูรายงานสต๊อก */}
            <div className="space-y-1">
              <button
                onClick={() => toggleMenu('reports')}
                className={menuButtonClass}
              >
                <span className="flex items-center gap-2">
                  <FaChartBar className="text-blue-200 group-hover:text-white" />
                  รายงานสต๊อก
                </span>
                <svg
                  className={`w-4 h-4 transform transition-transform duration-300 ${openMenu === 'reports' ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {openMenu === 'reports' && (
                <div className="pl-2 mt-1 space-y-1">
                  <NavLink to="/pos/stock/reports/inventory" className={linkClass}>
                    <FaClipboardList className="text-blue-600" />
                    รายงานสินค้าคงคลัง
                  </NavLink>
                  <NavLink to="/pos/stock/reports/movement" className={linkClass}>
                    <FaExchangeAlt className="text-blue-600" />
                    รายงานการเคลื่อนไหว
                  </NavLink>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default SidebarStock;