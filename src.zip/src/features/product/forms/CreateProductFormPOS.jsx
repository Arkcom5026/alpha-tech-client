import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useEffect } from 'react'
import useAlphaTechStore from '@/store/alphatech-store'
import { createProduct } from '@/api/product'
import { toast } from 'react-toastify'

const productSchema = z.object({
  code: z.string().min(1, 'กรุณากรอกรหัสสินค้า'),
  name: z.string().min(1, 'กรุณากรอกชื่อสินค้า'),
  spec: z.string().optional(),
  unit: z.string().optional(),
  price1: z.coerce.number().optional(),
  price2: z.coerce.number().optional(),
  price3: z.coerce.number().optional(),
  price4: z.coerce.number().optional(),
  price5: z.coerce.number().optional(),
  price6: z.coerce.number().optional(),
  cost: z.coerce.number().optional(),
  warranty: z.coerce.number().optional(),
  noSN: z.boolean().optional(),
  codeType: z.string().default('D')
})

const CreateProductFormPOS = ({ onSuccess }) => {
  const token = useAlphaTechStore((state) => state.token)
  const branchId = useAlphaTechStore((state) => state.branchId)

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: zodResolver(productSchema),
    defaultValues: {
      noSN: false,
      codeType: 'D',
    },
  })

  const onSubmit = async (data) => {
    try {
      const payload = {
        ...data,
        branchId,
      }
      await createProduct(token, payload)
      toast.success('เพิ่มสินค้าเรียบร้อยแล้ว')
      reset()
      onSuccess?.()
    } catch (err) {
      toast.error('เกิดข้อผิดพลาดในการบันทึกสินค้า')
      console.error(err)
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <label>รหัสสินค้า</label>
        <input {...register('code')} className="input" />
        {errors.code && <p className="text-red-500">{errors.code.message}</p>}
      </div>
      <div>
        <label>ชื่อสินค้า</label>
        <input {...register('name')} className="input" />
        {errors.name && <p className="text-red-500">{errors.name.message}</p>}
      </div>
      <div>
        <label>สเปก / รายละเอียด</label>
        <input {...register('spec')} className="input" />
      </div>
      <div>
        <label>หน่วย</label>
        <input {...register('unit')} className="input" />
      </div>
      <div>
        <label>ราคาขาย (ระดับ 1 - 6)</label>
        <div className="grid grid-cols-3 gap-2">
          <input type="number" step="0.01" {...register('price1')} placeholder="ราคา 1" className="input" />
          <input type="number" step="0.01" {...register('price2')} placeholder="ราคา 2" className="input" />
          <input type="number" step="0.01" {...register('price3')} placeholder="ราคา 3" className="input" />
          <input type="number" step="0.01" {...register('price4')} placeholder="ราคา 4" className="input" />
          <input type="number" step="0.01" {...register('price5')} placeholder="ราคา 5" className="input" />
          <input type="number" step="0.01" {...register('price6')} placeholder="ราคา 6" className="input" />
        </div>
      </div>
      <div>
        <label>ต้นทุน</label>
        <input type="number" step="0.01" {...register('cost')} className="input" />
      </div>
      <div>
        <label>ระยะเวลารับประกัน (วัน)</label>
        <input type="number" {...register('warranty')} className="input" />
      </div>
      <div>
        <label>
          <input type="checkbox" {...register('noSN')} /> ไม่มี Serial Number
        </label>
      </div>
      <input type="hidden" value="D" {...register('codeType')} />
      <button type="submit" className="btn btn-primary">บันทึกสินค้า</button>
    </form>
  )
}

export default CreateProductFormPOS
