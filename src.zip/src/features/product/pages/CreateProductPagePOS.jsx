import React from 'react'
import CreateProductFormPOS from '@/features/product/forms/CreateProductFormPOS'

const CreateProductPagePOS = () => {
  const handleSuccess = () => {
    // ทำอะไรบางอย่างหลังเพิ่มสินค้า เช่น reload หน้า หรือ redirect
    console.log('สินค้าใหม่ถูกเพิ่มแล้ว')
  }

  return (
    <div className="max-w-2xl mx-auto p-4">
      <h1 className="text-2xl font-semibold mb-4">เพิ่มสินค้าใหม่ (POS)</h1>
      <CreateProductFormPOS onSuccess={handleSuccess} />
    </div>
  )
}

export default CreateProductPagePOS
