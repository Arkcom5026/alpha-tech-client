import axios from 'axios'


export const createSupplier = async (token, form) => {
  return axios.post('http://localhost:5000/api/supplier', form, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};


export const listSuppliers = async (token,id) => {
  // code body  
  return axios.get(`http://localhost:5000/api/supplier/${id}`, {
    headers: {
      Authorization: `Bearer ${token}`
    }
  })
}


export const updateSupplier = async (token, id, form) => {
    console.log(form)
    return axios.put(`http://localhost:5000/api/supplier/${id}`, form, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  };

export const removeSupplier = async (token, id) => {
    // code body
    return axios.delete('http://localhost:5000/api/supplier/'+id, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    })
}

const supplier = () => {
    return (
      <div>supplier</div>
    )
  }
  
  export default supplier