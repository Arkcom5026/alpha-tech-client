// AddSupplierForm.jsx (ฟอร์มเวอร์ชันสมบูรณ์ พร้อมฟิลด์และปุ่มใน <form>)
import React, { useEffect } from 'react';
import { FaSave, FaUndo } from 'react-icons/fa';
import { useForm } from "react-hook-form";

import 'react-toastify/dist/ReactToastify.css';

import useAlphaTechStore from '@/store/alphatech-store';
import { supplierSchema } from '@/features/supplier/supplierSchema';

import { toast, ToastContainer } from 'react-toastify';
import { zodResolver } from '@hookform/resolvers/zod';
import { updateSupplier,createSupplier } from '@/features/supplier/api/supplierApi';


                                       


const AddSupplierForm = ({ selectedSupplier, isEdit = false, isViewMode = false, onSuccess, onCancel }) => {
  const token = useAlphaTechStore((state) => state.token);
  const branchId = useAlphaTechStore((state) => state.branch);
  const banks = useAlphaTechStore((state) => state.banks);
  const getBank = useAlphaTechStore((state) => state.getBank);

  const defaultValues = {
    name: '', contactPerson: '', phone: '', email: '', taxId: '',
    creditLimit: undefined, currentBalance: 0, address: '', province: '',
    postalCode: '', country: 'ประเทศไทย', bankId: '', accountNumber: '',
    accountType: '', paymentTerms: "30", notes: '', branchId: branchId,
  };

  const form = useForm({
    resolver: zodResolver(supplierSchema),
    defaultValues,
  });

  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = form;

  useEffect(() => { getBank(); }, []);

 useEffect(() => {
    if (selectedSupplier) {
      reset({
        name: '',
        contactPerson: '',
        phone: '',
        email: '',
        taxId: '',
        creditLimit: undefined,
        currentBalance: 0,
        address: '',
        province: '',
        postalCode: '',
        country: '',
        bankId: '',
        accountNumber: '',
        accountType: '',
        paymentTerms: '30',
        notes: '',
        branchId: branchId,
        ...selectedSupplier,
      });
    }
  }, [selectedSupplier, reset, branchId]);


  const onSubmit = async (data) => {
    try {
      console.log("submit", isEdit, selectedSupplier);
      const action = isEdit && selectedSupplier?.id
        ? updateSupplier(token, selectedSupplier.id, data)
        : createSupplier(token, data);

      const response = await action;
      const name = isEdit ? data.name : response.data.name;

      toast.success(`${isEdit ? 'อัปเดต' : 'เพิ่ม'}ข้อมูล ${name} สำเร็จ`);
      onSuccess?.();
    } catch (err) {
      console.error("❌ Error in onSubmit:", err); // <-- เพิ่มตรงนี้
      const status = err?.response?.status;
      const msg = status === 400 ? `ข้อมูลไม่ถูกต้อง: ${err.response.data.message || ''}` :
        status === 401 ? 'ไม่มีสิทธิ์ในการดำเนินการ' :
          status === 500 ? 'มีปัญหาที่เซิร์ฟเวอร์' : 'เกิดข้อผิดพลาดในการบันทึกข้อมูล';
      toast.error(msg, { position: 'top-center', autoClose: 5000 });
    }
  };

  const handleReset = () => {
    reset(selectedSupplier || defaultValues);
    toast.info('รีเซ็ตฟอร์มเรียบร้อยแล้ว', { position: 'top-center', autoClose: 2000 });
  };

  return (
    <>
      <ToastContainer />
      <form onSubmit={handleSubmit(onSubmit, (err) => console.log("onError formState.errors:", err))}>


        <div className="border-b pb-4 mb-4">
          <h2 className="text-xl font-bold text-gray-800">ข้อมูลผู้ขาย</h2>
          <p className="text-sm text-gray-500">กรุณากรอกข้อมูลให้ครบถ้วน</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">ชื่อผู้ขาย <span className="text-red-500">*</span></label>
            <input {...register('name')} className={`w-full px-3 py-2 border rounded-md ${errors.name ? 'border-red-500' : 'border-gray-300'}`} placeholder="บริษัท ตัวอย่าง จำกัด" />
            {errors.name && <p className="mt-1 text-sm text-red-500">{errors.name.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">ชื่อผู้ติดต่อ</label>
            <input {...register('contactPerson')} className="w-full px-3 py-2 border border-gray-300 rounded-md" placeholder="นางสาวตัวอย่าง ตัวอย่าง" />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">เบอร์โทรศัพท์</label>
            <input {...register('phone')} className={`w-full px-3 py-2 border rounded-md ${errors.phone ? 'border-red-500' : 'border-gray-300'}`} placeholder="0812345678" />
            {errors.phone && <p className="mt-1 text-sm text-red-500">{errors.phone.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">อีเมล</label>
            <input {...register('email')} className={`w-full px-3 py-2 border rounded-md ${errors.email ? 'border-red-500' : 'border-gray-300'}`} placeholder="supplier@example.com" />
            {errors.email && <p className="mt-1 text-sm text-red-500">{errors.email.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">เลขประจำตัวผู้เสียภาษี</label>
            <input {...register('taxId')} className={`w-full px-3 py-2 border rounded-md ${errors.taxId ? 'border-red-500' : 'border-gray-300'}`} placeholder="1234567890123" />
            {errors.taxId && <p className="mt-1 text-sm text-red-500">{errors.taxId.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">วงเงินเครดิต (บาท)</label>
            <input {...register('creditLimit', { valueAsNumber: true })} type="number" className={`w-full px-3 py-2 border rounded-md ${errors.creditLimit ? 'border-red-500' : 'border-gray-300'}`} placeholder="100000" step="0.01" />
            {errors.creditLimit && <p className="mt-1 text-sm text-red-500">{errors.creditLimit.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">ยอดค้างชำระปัจจุบัน (บาท)</label>
            <input {...register('currentBalance', { valueAsNumber: true })} type="number" className={`w-full px-3 py-2 border rounded-md ${errors.currentBalance ? 'border-red-500' : 'border-gray-300'}`} placeholder="0" step="0.01" />
            {errors.currentBalance && <p className="mt-1 text-sm text-red-500">{errors.currentBalance.message}</p>}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">ที่อยู่</label>
            <textarea {...register('address')} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-md" placeholder="เลขที่, หมู่, ถนน, ตำบล/แขวง" />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">จังหวัด</label>
            <input {...register('province')} className="w-full px-3 py-2 border border-gray-300 rounded-md" placeholder="กรุงเทพมหานคร" />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">รหัสไปรษณีย์</label>
            <input {...register('postalCode')} className={`w-full px-3 py-2 border rounded-md ${errors.postalCode ? 'border-red-500' : 'border-gray-300'}`} placeholder="10100" />
            {errors.postalCode && <p className="mt-1 text-sm text-red-500">{errors.postalCode.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">ประเทศ</label>
            <input {...register('country')} className="w-full px-3 py-2 border border-gray-300 rounded-md" placeholder="ประเทศไทย" />
          </div>
        </div>

        <div className="border-t pt-4 mt-4">
          <h3 className="text-lg font-medium text-gray-800 mb-3">ข้อมูลบัญชีธนาคาร</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">ชื่อธนาคาร</label>

              <select {...register('bankId')} disabled={isViewMode} defaultValue=""
                className={`w-full px-3 py-1.5 text-sm border rounded-md ${errors.bankId ? 'border-red-500' : 'border-gray-300'}`}>
                <option value="">เลือกธนาคาร</option>
                {banks.map((bank) => (
                  <option key={bank.id} value={bank.id.toString()}>{bank.name}</option>
                ))}
              </select>

              {errors.bankId && <p className="mt-1 text-xs text-red-500">{errors.bankId.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">หมายเลขบัญชี</label>
              <input {...register('accountNumber')} className={`w-full px-3 py-2 border rounded-md ${errors.accountNumber ? 'border-red-500' : 'border-gray-300'}`} placeholder="1234567890" />
              {errors.accountNumber && <p className="mt-1 text-sm text-red-500">{errors.accountNumber.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">ประเภทบัญชี</label>
              <select {...register('accountType')} className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md">
                <option value="">เลือกประเภท</option>
                <option value="ออมทรัพย์">ออมทรัพย์</option>
                <option value="กระแสรายวัน">กระแสรายวัน</option>
              </select>
            </div>
          </div>
        </div>



        {!isViewMode && (
          <div className="flex justify-end space-x-4 pt-4 border-t">
            <button type="button" onClick={handleReset} className="flex items-center px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300" disabled={isSubmitting}>
              <FaUndo className="mr-2" /> รีเซ็ต
            </button>
            <button type="submit" className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-blue-400" disabled={isSubmitting}>
              <FaSave className="mr-2" /> {isSubmitting ? 'กำลังบันทึก...' : 'บันทึกข้อมูล'}
            </button>
          </div>
        )}

        {isViewMode && (
          <div className="flex justify-end pt-4 border-t">
            <button type="button" onClick={onCancel} className="flex items-center px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300">
              ปิด
            </button>
          </div>
        )}
      </form>
    </>
  );
};

export default AddSupplierForm;
