// ListSupplierForm.jsx (เวอร์ชันสมบูรณ์ พร้อมปรับปรุงตามคำแนะนำ)
import { useState, useEffect, useMemo } from "react";
import { FaEdit, FaEye, FaTrash, FaSearch, FaPlus } from "react-icons/fa";
import useAlphaTechStore from "@/store/alphatech-store";
import { removeSupplier } from "@features/supplier/api/supplierApi";
import { toast } from "react-toastify";
import AddSupplierForm from "@features/supplier/forms/AddSupplierForm";


const ListSupplierForm = () => {
  const token = useAlphaTechStore((state) => state.token);
  const suppliers = useAlphaTechStore((state) => state.suppliers);
  const getSuppliers = useAlphaTechStore((state) => state.getSuppliers);

  const [formState, setFormState] = useState({ open: false, mode: "add", supplier: null });
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    if (token) {
      getSuppliers(token);
    }
  }, [token]);

  useEffect(() => {
    if (formState.open) {
      window.scrollTo(0, 0);
    }
  }, [formState.open]);

  const handleDelete = async (id) => {
    if (window.confirm("คุณแน่ใจว่าต้องการลบผู้ขายนี้?")) {
      try {
        await removeSupplier(token, id);
        toast.success("ลบผู้ขายสำเร็จ");
        getSuppliers(token);
      } catch (error) {
        console.error("Error deleting supplier:", error);
        toast.error("เกิดข้อผิดพลาดขณะลบผู้ขาย");
      }
    }
  };

  const handleAdd = () => setFormState({ open: true, mode: "add", supplier: null });
  const handleEdit = (supplier) => setFormState({ open: true, mode: "edit", supplier });
  const handleView = (supplier) => setFormState({ open: true, mode: "view", supplier });
  const handleClose = () => setFormState({ open: false, mode: "add", supplier: null });
  const handleSuccess = () => { getSuppliers(token); handleClose(); };

  const filteredSuppliers = useMemo(() => {
    return suppliers?.filter((supplier) => supplier.name?.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [suppliers, searchTerm]);

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">รายชื่อผู้ขาย</h1>

      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <div className="relative w-full md:w-1/2">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <FaSearch className="text-gray-400" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            placeholder="ค้นหาผู้ขาย..."
          />
        </div>

        <div className="w-full md:w-auto text-right">
          <button
            onClick={handleAdd}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition flex items-center gap-2"
          >
            <FaPlus /> เพิ่มผู้ขาย
          </button>
        </div>
      </div>

      <div className="overflow-x-auto bg-white rounded-lg shadow">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">รหัสผู้ขาย</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ชื่อบริษัท</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ชื่อผู้ติดต่อ</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">เบอร์โทร</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ยอดค้าง</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">การดำเนินการ</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredSuppliers?.map((item) => (
              <tr key={item.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.id}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.contactPerson}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.phone}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {Number(item.currentBalance).toLocaleString('th-TH', { style: 'currency', currency: 'THB' })}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <div className="inline-flex items-center space-x-4">
                    <button onClick={() => handleView(item)} className="text-blue-600 hover:text-blue-900 transition-colors duration-200" title="ดูรายละเอียด">
                      <FaEye className="w-5 h-5" />
                    </button>
                    <button onClick={() => handleEdit(item)} className="text-yellow-600 hover:text-yellow-900 transition-colors duration-200" title="แก้ไข">
                      <FaEdit className="w-5 h-5" />
                    </button>
                    <button onClick={() => handleDelete(item.id)} className="text-red-600 hover:text-red-900 transition-colors duration-200" title="ลบ">
                      <FaTrash className="w-5 h-5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {formState.open && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto p-4 md:p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-start mb-4">
              <h2 className="text-xl font-bold">
                {formState.mode === 'add' ? 'เพิ่มผู้ขายใหม่' : formState.mode === 'edit' ? 'แก้ไขผู้ขาย' : 'ดูรายละเอียดผู้ขาย'}
              </h2>
              <button onClick={handleClose} className="text-gray-500 hover:text-gray-700 text-2xl">&times;</button>
            </div>
            <AddSupplierForm
              selectedSupplier={formState.supplier}
              isEdit={formState.mode === 'edit'}
              isViewMode={formState.mode === 'view'}
              onSuccess={handleSuccess}
              onCancel={handleClose}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default ListSupplierForm;
