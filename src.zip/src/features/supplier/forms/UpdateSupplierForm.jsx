import { useForm } from "react-hook-form";
import { FaSave, FaUndo } from "react-icons/fa";
import useAlphaTechStore from "../../../store/alphatech-store";
import { useEffect } from "react";

const UpdateSupplierForm = ({

  initialData = {},
  onSubmit,
  isViewMode = false,
  isLoading = false
}) => {

  const getBank = useAlphaTechStore((state) => state.getBank);
  const banks = useAlphaTechStore((state) => state.banks);

  useEffect(() => {
    getBank();
  }, [getBank]);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm({
    defaultValues: {
      isActive: true,
      paymentTerms: 30,
      country: "Thailand",
      ...initialData
    }
  });


  return (

    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 p-6 bg-white rounded-lg shadow-md">
      {/* ส่วนหัวฟอร์ม */}
      <div className="border-b pb-4 mb-4">
        <h2 className="text-xl font-bold text-gray-800">ข้อมูลผู้ขาย</h2>
        <p className="text-sm text-gray-500">กรุณากรอกข้อมูลให้ครบถ้วน</p>
      </div>

      {/* ข้อมูลพื้นฐาน */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 1. ชื่อผู้ขาย */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            ชื่อผู้ขาย <span className="text-red-500">*</span>
          </label>
          <input
            {...register('name', { required: 'กรุณากรอกชื่อผู้ขาย' })}
            className={`w-full px-3 py-2 border rounded-md ${errors.name ? 'border-red-500' : 'border-gray-300'
              }`}
            placeholder="บริษัท ตัวอย่าง จำกัด"
          />
          {errors.name && <p className="mt-1 text-sm text-red-500">{errors.name.message}</p>}
        </div>

        {/* 2. ชื่อผู้ติดต่อ */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">ชื่อผู้ติดต่อ</label>
          <input
            {...register('contactPerson')}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            placeholder="นางสาวตัวอย่าง ตัวอย่าง"
          />
        </div>

        {/* 3. เบอร์โทรศัพท์ */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">เบอร์โทรศัพท์</label>
          <input
            {...register('phone', {
              pattern: {
                value: /^[0-9]{9,10}$/,
                message: 'รูปแบบเบอร์โทรศัพท์ไม่ถูกต้อง (ควรเป็นตัวเลข 9-10 หลัก)',
              },
            })}
            className={`w-full px-3 py-2 border rounded-md ${errors.phone ? 'border-red-500' : 'border-gray-300'
              }`}
            placeholder="0812345678"
          />
          {errors.phone && <p className="mt-1 text-sm text-red-500">{errors.phone.message}</p>}
        </div>

        {/* 4. อีเมล */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">อีเมล</label>
          <input
            {...register('email', {
              pattern: {
                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                message: 'รูปแบบอีเมลไม่ถูกต้อง',
              },
            })}
            className={`w-full px-3 py-2 border rounded-md ${errors.email ? 'border-red-500' : 'border-gray-300'
              }`}
            placeholder="supplier@example.com"
          />
          {errors.email && <p className="mt-1 text-sm text-red-500">{errors.email.message}</p>}
        </div>

        {/* 5. เลขประจำตัวผู้เสียภาษี */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">เลขประจำตัวผู้เสียภาษี</label>
          <input
            {...register('taxId', {
              pattern: {
                value: /^[0-9]{13}$/,
                message: 'รูปแบบเลขประจำตัวผู้เสียภาษีไม่ถูกต้อง (ควรเป็นตัวเลข 13 หลัก)',
              },
            })}
            className={`w-full px-3 py-2 border rounded-md ${errors.taxId ? 'border-red-500' : 'border-gray-300'
              }`}
            placeholder="1234567890123"
          />
          {errors.taxId && <p className="mt-1 text-sm text-red-500">{errors.taxId.message}</p>}
        </div>

        {/* 6. วงเงินเครดิต */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">วงเงินเครดิต (บาท)</label>
          <input
            {...register('creditLimit', {
              min: {
                value: 0,
                message: 'วงเงินเครดิตต้องไม่ต่ำกว่า 0',
              },
            })}
            type="number"
            className={`w-full px-3 py-2 border rounded-md ${errors.creditLimit ? 'border-red-500' : 'border-gray-300'
              }`}
            placeholder="100000"
            step="0.01"
          />
          {errors.creditLimit && (
            <p className="mt-1 text-sm text-red-500">{errors.creditLimit.message}</p>
          )}
        </div>

        {/* 7. ยอดค้างชำระปัจจุบัน */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            ยอดค้างชำระปัจจุบัน (บาท)
          </label>
          <input
            {...register('currentBalance', {
              min: {
                value: 0,
                message: 'ยอดค้างชำระต้องไม่ต่ำกว่า 0',
              },
            })}
            type="number"
            className={`w-full px-3 py-2 border rounded-md ${errors.currentBalance ? 'border-red-500' : 'border-gray-300'
              }`}
            placeholder="0"
            step="0.01"
          />
          {errors.currentBalance && (
            <p className="mt-1 text-sm text-red-500">{errors.currentBalance.message}</p>
          )}
        </div>
      </div>

      {/* ที่อยู่ */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* 8. ที่อยู่ */}
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">ที่อยู่</label>
          <textarea
            {...register('address')}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            placeholder="เลขที่, หมู่, ถนน, ตำบล/แขวง"
          />
        </div>

        {/* 9. จังหวัด */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">จังหวัด</label>
          <input
            {...register('province')}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            placeholder="กรุงเทพมหานคร"
          />
        </div>

        {/* 10. รหัสไปรษณีย์ */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">รหัสไปรษณีย์</label>
          <input
            {...register('postalCode', {
              pattern: {
                value: /^[0-9]{5}$/,
                message: 'รูปแบบรหัสไปรษณีย์ไม่ถูกต้อง (ควรเป็นตัวเลข 5 หลัก)',
              },
            })}
            className={`w-full px-3 py-2 border rounded-md ${errors.postalCode ? 'border-red-500' : 'border-gray-300'
              }`}
            placeholder="10100"
          />
          {errors.postalCode && (
            <p className="mt-1 text-sm text-red-500">{errors.postalCode.message}</p>
          )}
        </div>

        {/* 11. ประเทศ */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">ประเทศ</label>
          <input
            {...register('country')}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            placeholder="ประเทศไทย"
          />
        </div>
      </div>

      {/* ข้อมูลบัญชีธนาคาร */}
      <div className="border-t pt-4 mt-4">
        <h3 className="text-lg font-medium text-gray-800 mb-3">ข้อมูลบัญชีธนาคาร</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

          {/* 12. ชื่อธนาคาร */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">ชื่อธนาคาร</label>
            <select
              {...register('bankId', { required: 'กรุณาเลือกธนาคาร' })}
              className={`w-full px-3 py-1.5 text-sm border rounded-md ${errors.bankId ? 'border-red-500' : 'border-gray-300'
                }`}
            >
              <option value="">เลือกธนาคาร</option>
              {banks.map((bank) => (
                <option key={bank.id} value={bank.id}> {/* ใช้ bank._id เป็น value */}
                  {bank.name} {/* แสดงชื่อธนาคารให้ผู้ใช้เห็น */}
                </option>
              ))}
            </select>
            {errors.bankId && (
              <p className="mt-1 text-xs text-red-500">{errors.bankId.message}</p>
            )}
          </div>

          {/* 13. หมายเลขบัญชี */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">หมายเลขบัญชี</label>
            <input
              {...register('accountNumber', {
                pattern: {
                  value: /^[0-9]+$/,
                  message: 'กรุณากรอกเฉพาะตัวเลข',
                },
              })}
              className={`w-full px-3 py-2 border rounded-md ${errors.accountNumber ? 'border-red-500' : 'border-gray-300'
                }`}
              placeholder="1234567890"
            />
            {errors.accountNumber && (
              <p className="mt-1 text-sm text-red-500">{errors.accountNumber.message}</p>
            )}
          </div>

          {/* 14. ประเภทบัญชี */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">ประเภทบัญชี</label>
            <select
              {...register('accountType')}
              className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md"
            >
              <option value="">เลือกประเภท</option>
              <option value="ออมทรัพย์">ออมทรัพย์</option>
              <option value="กระแสรายวัน">กระแสรายวัน</option>
            </select>
          </div>
        </div>
      </div>

      {/* ข้อมูลอื่นๆ */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* 15. เงื่อนไขการชำระเงิน */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            เงื่อนไขการชำระเงิน (วัน)
          </label>
          <select
            {...register('paymentTerms')}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          >
            <option value="30">ชำระภายใน 30 วัน</option>
            <option value="15">ชำระภายใน 15 วัน</option>
            <option value="7">ชำระภายใน 7 วัน</option>
            <option value="0">ชำระเงินสด</option>
          </select>
        </div>

        {/* 16. หมายเหตุ */}
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">หมายเหตุ</label>
          <textarea
            {...register('notes')}
            rows={2}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            placeholder="หมายเหตุเพิ่มเติม..."
          />
        </div>
      </div>



      {/* ปุ่มดำเนินการ */}
      {!isViewMode && (
        <div className="flex justify-end space-x-3 pt-4">
          <button
            type="button"
            onClick={() => reset()}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 flex items-center"
            disabled={isLoading}
          >
            <FaUndo className="mr-2" /> ล้างข้อมูล
          </button>

          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                กำลังบันทึก...
              </>
            ) : (
              <>
                <FaSave className="mr-2" /> บันทึกข้อมูล
              </>
            )}
          </button>
        </div>
      )}

    </form>
  );
};

export default UpdateSupplierForm;