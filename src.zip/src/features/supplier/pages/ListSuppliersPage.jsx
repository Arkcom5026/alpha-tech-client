import React from 'react'
import ListSupplierForm from '@features/supplier/forms/ListSupplierForm'

const ListSuppliersPage = () => {
  return (
    <div>

     <ListSupplierForm />  
    
    </div>
  )
}

export default ListSuppliersPage