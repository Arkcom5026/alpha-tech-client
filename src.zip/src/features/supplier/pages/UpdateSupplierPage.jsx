import React from 'react';
import UpdateSupplierForm from '@features/supplier/forms/UpdateSupplierForm';

const UpdateSupplierPage = () => {

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">เพิ่มข้อมูลผู้ขาย</h1>
      <UpdateSupplierForm onSubmit={handleSubmit} />
    </div>
  );
};

export default UpdateSupplierPage;
