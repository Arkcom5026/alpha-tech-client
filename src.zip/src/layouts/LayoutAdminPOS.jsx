import React from 'react'
import { Outlet } from 'react-router-dom'

import HeaderAdminPOS from '@/components/pos/HeaderAdminPos'
import SidebarAdminPOS from '@/components/pos/sidebars/SidebarAdminPos'



const LayoutAdminPOS = () => {
    return (
        <div className='flex h-screen'>
        <SidebarAdminPOS />
        <div className='flex-1 flex flex-col'>
            <HeaderAdminPOS />
            <main className='flex-1 p-6
           bg-gray-100 overflow-y-auto'>
                <Outlet />
            </main>
        </div>
    </div>
    )
}

export default LayoutAdminPOS