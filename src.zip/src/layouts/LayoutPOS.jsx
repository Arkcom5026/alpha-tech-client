import HeaderPOS from '@/components/pos/HeaderPos'
import SidebarFinance from '@/components/pos/sidebars/SidebarFinance'
import SidebarLogout from '@/components/pos/sidebars/SidebarLogout'
import SidebarPurchases from '@/components/pos/sidebars/SidebarPurchases'
import SidebarReports from '@/components/pos/sidebars/SidebarReports'
import SidebarSales from '@/components/pos/sidebars/SidebarSales'
import SidebarServices from '@/components/pos/sidebars/SidebarServices'
import SidebarStock from '@/components/pos/sidebars/SidebarStock'
import React from 'react'
import { Outlet, useLocation } from 'react-router-dom'

const LayoutPOS = () => {
    const location = useLocation()
    
    // ตรวจสอบ path ปัจจุบันเพื่อเลือก Sidebar ที่เหมาะสม
    const getSidebarComponent = () => {
        if (location.pathname.includes('/pos/purchases')) {
            return <SidebarPurchases />
        } else if (location.pathname.includes('/pos/sales')) {
            return <SidebarSales />        
        } else if (location.pathname.includes('/pos/services')) {
            return <SidebarServices />        
        } else if (location.pathname.includes('/pos/finance')) {
            return <SidebarFinance  />               
        } else if (location.pathname.includes('/pos/stock')) {
            return <SidebarStock  />               
        } else if (location.pathname.includes('/pos/reports')) {
            return <SidebarReports  />               
        } else if (location.pathname.includes('/pos/logout')) {
            return <SidebarLogout />
        }
        
        return <SidebarPurchases />
    }

    return (
        <div className='flex h-screen'>
            {getSidebarComponent()}
            <div className='flex-1 flex flex-col'>
                <HeaderPOS/>
                <main className='flex-1 p-6 bg-gray-100 overflow-y-auto'>
                    <Outlet />
                </main>
            </div>
        </div>
    )
}

export default LayoutPOS

