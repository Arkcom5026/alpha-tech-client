import React from 'react'
import ListCart from '../components/card/ListCart'

const Cart = () => {
  return (
    <div>
      <ListCart />
    </div>
  )
}

export default Cart