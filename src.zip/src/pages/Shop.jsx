import React, { useEffect } from 'react'
import ProductCard from '../components/card/ProductCard'
import useAlphaTechStore from '../store/alphatech-store'
import SearchCard from '../components/card/SearchCard'
import CartCard from '../components/card/CartCard'


const Shop = () => {

  const getProdcut = useAlphaTechStore((state) => state.getProduct)
  const products = useAlphaTechStore((state) => state.products)
  
  useEffect(() => {
    getProdcut(10)    
  },[])

  return (
    <div className='flex '>
      {/* SearchBar */}
      <div className='w-1/4 p-4 bg-blue-100 h-screen overflow-auto'>

         <SearchCard /> 

      </div>


      {/* Product */}
      <div className='w-1/2 p-4  h-screen overflow-auto'>
        <p className='text -2xl font-bold mb-4'> สินค้าทั้งหมด </p>
        <div className='flex flex-wrap gap-4'>
          {/* Product Card */}
          {
            products.map((item,index)=>
              <ProductCard key={index} item={item} />
            )
          }
          

        </div>
      </div>

      {/* Cart */}
      <div className='w-1/4 p-4 bg-blue-100  h-screen overflow-auto'>       
        <CartCard /> 
      </div>

    </div>
  )
}

export default Shop