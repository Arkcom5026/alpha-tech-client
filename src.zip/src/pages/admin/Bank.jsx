import React from 'react'
import FormBank from '../../components/admin/FormBank'

const Bank = () => {
  return (
    <div><FormBank /></div>
  )
}

export default Bank