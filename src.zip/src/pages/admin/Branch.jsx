import React from 'react'
import FormBank from '../../components/admin/FormBank'
import FormBranch from '../../components/admin/FormBranch'

const Branch = () => {
  return (
    <div><FormBranch /></div>
  )
}

export default Branch