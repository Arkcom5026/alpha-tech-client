import React from 'react'
import FormCategory from '../../components/admin/FormCategory'

const Category = () => {
  return (
    <div>
      <FormCategory />      
    </div>
  )
}

export default Category