import React from 'react'
import FormEditProduct from '../../components/admin/FormEditProduct'

const EditProduct = () => {
  return (
    <div><FormEditProduct /></div>
  )
}

export default EditProduct