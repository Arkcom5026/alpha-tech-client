import React from 'react'
import TableOrders from '../../components/admin/TableOrders'

const ManageOrder = () => {
  return (
    <div><TableOrders /></div>
  )
}

export default ManageOrder
