import React from 'react'
import FormProduct from '../../components/admin/FormPruduct'



const Product = () => {
  return (
    <div>
      <FormProduct />
    </div>
  )
}

export default Product