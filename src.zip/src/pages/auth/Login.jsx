import React from "react";
import OnlineLogin from "../../components/auth/OnlineLogin";

const Login = () => {

  return (
   <OnlineLogin />
  )
}

export default Login