import React from 'react'

const PosLogin = () => {
  return (
   <div>
        PosLogin
   </div>
  )
}

export default PosLogin