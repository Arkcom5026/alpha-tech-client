import React from "react";
import OnlineRegister from "../../components/auth/OnlineRegister";


const Register  = () => {


  return (

    <OnlineRegister />

  )
}

export default Register;

