import React from 'react'
import PosRegister from '../../components/auth/PosRegister'

const RegisterPos = () => {
  return (
    <div>
      <PosRegister />
      </div>
  )
}

export default RegisterPos