import React from 'react'

const DashboardPOS = () => {
  return (
    <div>DashboardPOS</div>
  )
}

export default DashboardPOS
