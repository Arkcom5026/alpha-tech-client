import React from 'react'

const Finance = () => {
  return (
    <div>การเงิน</div>
  )
}

export default Finance