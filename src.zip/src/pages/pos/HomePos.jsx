import React from 'react'
import PosLogin from '../../components/auth/PosLogin'

const HomePos = () => {
  return (
 
    <PosLogin />

  )
  
}

export default HomePos