
const LogoutPOS = () => <div className="p-4 text-xl">ออกจากระบบ</div>;
export default LogoutPOS;