import React from 'react'

const MainPos = () => {
  return (
    <div>MainPos</div>
  )
}

export default MainPos