import React from 'react'
import FormPosition from '../../components/pos/FormPosition'

const Position = () => {
    //<FormPosition />
  return (
    <div>
        Halo Position

    </div>
  )
}

export default Position