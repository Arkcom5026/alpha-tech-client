import React from 'react'

const Purchases = () => {
  return (
    <div>Purchases</div>
  )
}

export default Purchases