import React from 'react'
import PosRegister from '../../components/auth/PosRegister'


const RegisterPos = () => {
  return (
    <PosRegister />
  )
}

export default RegisterPos