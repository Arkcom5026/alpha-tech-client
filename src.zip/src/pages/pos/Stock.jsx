import React from 'react'

const Stock = () => {
  return (
    <div>Stock</div>
  )
}

export default Stock