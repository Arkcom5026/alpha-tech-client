import React from 'react'
import ListPurchaseOrderForm from '../../../../components/pos/formpos/ListPurchaseOrderForm'

const ListPurchaseOrder = () => {
  return (
    <div>
      <h1>Purchase Order</h1>
      <ListPurchaseOrderForm />
    </div>
  );
};

export default ListPurchaseOrder