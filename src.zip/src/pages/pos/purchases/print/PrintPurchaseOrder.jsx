import React from 'react';
import PrintPurchaseOrder from '../../../../components/pos/print/purchase-order/PrintPurchaseOrder';

const PrintPurchaseOrder = () => {
    const sampleOrder = {
        poNumber: "PO-2023-00123",
        orderDate: new Date(),
        supplier: {
            name: "บริษัท ซัพพลายเออร์ ตัวอย่าง จำกัด",
            address: "456 ถนนจัดส่ง อำเภอทดสอบ จังหวัดตัวอย่าง 10200",
            phone: "02-987-6543",
            contactPerson: "คุณสมชาย ตัวอย่าง",
            taxId: "9876543210123"
        },
        items: [
            {
                productCode: "P-001",
                productName: "สินค้าตัวอย่าง A",
                quantity: 10,
                unit: "ชิ้น",
                unitPrice: 1200,
                discount: 5
            },
            {
                productCode: "P-002",
                productName: "สินค้าตัวอย่าง B",
                quantity: 5,
                unit: "กล่อง",
                unitPrice: 2500,
                discount: 10
            }
        ],
        subtotal: 24500,
        taxRate: 7,
        taxAmount: 1715,
        discount: 2450,
        totalAmount: 23765,
        paymentTerms: 30,
        deliveryDate: new Date(new Date().setDate(new Date().getDate() + 14)),
        notes: "กรุณาจัดส่งสินค้าทุกชิ้นพร้อมใบกำกับภาษีเต็มรูป"
    };

    return <PrintPurchaseOrder order={sampleOrder} />;
};

export default PrintPurchaseOrder;