import React from 'react'
import SummaryCard from '../../components/card/SummaryCard'

const Checkout = () => {
  return (
    <div>
      <SummaryCard />
    </div>
  )
}

export default Checkout