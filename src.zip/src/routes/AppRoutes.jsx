import OnlineLogin from '@/components/auth/OnlineLogin'
import OnlineRegister from '@/components/auth/OnlineRegister'
import RegisterPos from '@/pages/auth/RegisterPos'
import Cart from '@/pages/Cart'
import HomePos from '@/pages/pos/HomePos'
import Shop from '@/pages/Shop'
import Checkout from '@/pages/user/Checkout'
import React from 'react'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
//import ProtectRouteAdmin from './ProtectRouteAdmin'
import LayoutAdmin from '@/layouts/LayoutAdmin'
import Dashboard from '@/pages/admin/Dashboard'
import Category from '@/pages/admin/Category'
import Product from '@/pages/admin/Product'
import Bank from '@/pages/admin/Bank'
import Branch from '@/pages/admin/Branch'
import EditProduct from '@/pages/admin/EditProduct'
import Manage from '@/pages/admin/Manage'
import ManageOrder from '@/pages/admin/ManageOrder'
//import ProtectRouteUser from './ProtectRoutePos'
import LayoutUser from '@/layouts/LayoutUser'
import HomeUser from '@/pages/user/HomeUser'
import Payment from '@/pages/user/Payment'
import History from '@/pages/user/History'

import DashboardPOS from '@/pages/pos/DashboardPos'
import Purchases from '@/pages/pos/Purchases'
import PurchaseOrder from '@/pages/pos/purchases/orders/PurchaseOrder'
import ListPurchaseOrder from '@/pages/pos/purchases/orders/ListPurchaseOrder'
import PrintPurchaseOrder from '@/components/pos/print/purchase-order/PrintPurchaseOrder'
import AddSupplierForm from '@/features/supplier/forms/AddSupplierForm'
import ListSuppliers from '@/features/supplier/pages/ListSuppliersPage'
import Sales from '@/pages/pos/Sales'
import Services from '@/pages/pos/Services'
import Finance from '@/pages/pos/Finance'
import Stock from '@/pages/pos/Stock'
import Reports from '@/pages/pos/Reports'
import LogoutPOS from '@/pages/pos/LogoutPos'
import Layout from '@/layouts/Layout'
import Home from '@/pages/Home'
import LayoutPOS from '@/layouts/LayoutPOS'


const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      { index: true, element: <Home /> },
      { path: 'shop', element: <Shop /> },
      { path: 'cart', element: <Cart /> },
      { path: 'checkout', element: <Checkout /> },
      { path: 'onlineLogin', element: <OnlineLogin /> },
      { path: 'onlineRegister', element: <OnlineRegister /> },
      { path: 'pos/homepos', element: <HomePos /> },
      { path: 'pos/registerpos', element: <RegisterPos /> },
    ]
  },
  {
    path: '/admin',
    element: (
      <LayoutAdmin />
    ),
    children: [
      { index: true, element: <Dashboard /> },
      { path: 'category', element: <Category /> },
      { path: 'product', element: <Product /> },
      { path: 'bank', element: <Bank /> },
      { path: 'branch', element: <Branch /> },
      { path: 'product/:id', element: <EditProduct /> },
      { path: 'manage', element: <Manage /> },
      { path: 'orders', element: <ManageOrder /> },
    ]
  },
  {
    path: '/user',
    element: (      
        <LayoutUser />      
    ),
    children: [
      { index: true, element: <HomeUser /> },
      { path: 'payment', element: <Payment /> },
      { path: 'history', element: <History /> },
    ]
  },
  {
    path: '/pos',
    element: <LayoutPOS />,
    children: [
      { index: true, element: <DashboardPOS /> },
      { path: 'purchases', element: <Purchases /> },
      { path: 'purchases/orders/purchaseorder', element: <PurchaseOrder /> },
      { path: 'purchases/orders/listpurchaseorder', element: <ListPurchaseOrder /> },
      { path: 'purchases/print/printpurchaseorder', element: <PrintPurchaseOrder /> },
      { path: 'purchases/suppliers/addsupplier', element: <AddSupplierForm /> },
      { path: 'purchases/suppliers/listsuppliers', element: <ListSuppliers /> },
      { path: 'sales', element: <Sales /> },
      { path: 'services', element: <Services /> },
      { path: 'finance', element: <Finance /> },
      { path: 'stock', element: <Stock /> },
      { path: 'reports', element: <Reports /> },
      { path: 'logoutpos', element: <LogoutPOS /> },
    ]
  }
])

const AppRoutes = () => {
  return <RouterProvider router={router} />
}

export default AppRoutes