import React, { useState, useEffect } from 'react'
import useAlphaTechStore from '../store/alphatech-store'
import { currentEmployee } from '../api/authpos'
import LoadingToredirect from './LoadingToredirect'


const ProtectRouteUser = ({ element }) => {
  
  const [ok, setOk] = useState(false)

  const employee = useAlphaTechStore((state) => state.employee)
  const token = useAlphaTechStore((state) => state.token)
  
  useEffect(() => {
    if (employee && token) {
      currentEmployee(token)
     .then((res) => setOk(true))
     .catch((err) => setOk(false))
    }
    
  },[])

  return ok ? element : <LoadingToredirect  />
 // return  element
}

export default ProtectRouteUser