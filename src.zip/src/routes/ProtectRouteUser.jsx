import React, { useState, useEffect } from 'react'
import useAlphaTechStore from '../store/alphatech-store'
import { currentUser } from '../api/auth'
import LoadingToredirect from './LoadingToredirect'


const ProtectRouteUser = ({ element }) => {
  
  const [ok, setOk] = useState(false)

  const user = useAlphaTechStore((state) => state.user)
  const token = useAlphaTechStore((state) => state.token)

  useEffect(() => {
    if (user && token) {
     currentUser(token)
     .then((res) => setOk(true))
     .catch((err) => setOk(false))
    }
    
  },[])

  return ok ? element : <LoadingToredirect  />
 // return  element
}

export default ProtectRouteUser