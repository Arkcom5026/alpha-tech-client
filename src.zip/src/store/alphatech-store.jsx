import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import axios from 'axios'
import { listCategory } from '../api/category';
import { listProduct, searchFilters } from '../api/product';
import _ from 'lodash'
import { listSuppliers } from '@features/supplier/api/supplierApi';
import { listBank } from '../api/bank';
import { listBranch } from '../api/branch';

const alphaTechStore = (set, get) => ({
    user: null,
    employee: null,
    token: null,
    categories: [],
    products: [],
    carts: [],
    suppliers: [],
    banks: [],
    branch: [],
    branchName: [],
    Branch:[],

    logout: () => {
        set({
            user: null,
            employee: null,
            token: null,
            categories: [],
            products: [],
            carts: [],
        })
    },

    actionAddtoCart: (product) => {
        const carts = get().carts
        const updateCart = [...carts, { ...product, count: 1 }]

        // Step Uniqe
        const uniqe = _.unionWith(updateCart, _.isEqual)

        set({ carts: uniqe })
    },

    actionUpdateQuantity: (productId, newQuantity) => {
        set((state) => ({
            carts: state.carts.map((item) =>
                item.id === productId
                    ? { ...item, count: Math.max(1, newQuantity) }
                    : item
            )
        }))
    },

    actionLogin: async (form) => {
        try {
            const res = await axios.post('http://localhost:5000/api/loginUser', form, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            set({
                user: res.data.payload,
                token: res.data.token
            });
            return res;
        } catch (err) {
            console.error('Login Action Error:', err.response?.data);
            throw err;
        }
    },

    actionLoginEmploye: async (form) => {
        try {
            const res = await axios.post('http://localhost:5000/api/loginemployee', form, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const { payload, token } = res.data;

            set({
                employee: payload,
                token: token,
                branch: payload.branch.id,
                branchName: payload.branch.name
            });

           // console.log('actionLoginEmploye : ', payload.branch.id)

            return res;
        } catch (err) {
            console.error('Login Action Error:', err.response?.data);
            throw err;
        }
    },

    actionRemoveProduct: (productId) => {
        // console.log('remove jaaaaa', productId)
        set((state) => ({
            carts: state.carts.filter((item) => item.id !== productId),
        }));
    },

    getCategory: async () => {
        try {
            const res = await listCategory()
            set({ categories: res.data })

        } catch (err) {
            console.log(err)
        }
    },

    getProduct: async (count) => {
        try {
            const res = await listProduct(count)
            set({ products: res.data })

        } catch (err) {
            console.log(err)
        }
    },

    getBank: async (count) => {
        try {
            const res = await listBank(count)
            set({ banks: res.data })

        } catch (err) {
            console.log(err)
        }
    },

    getBranch: async () => {
        try {
            const res = await listBranch()
            set({ Branch: res.data })

        } catch (err) {
            console.log(err)
        }
    },

    getSuppliers: async () => {
        try {
          const token = get().token;
          const branch = get().branch;
          if (!token) throw new Error("Token is missing");
      
          // 1. เรียก API และได้ response แบบเดิม
          const res = await listSuppliers(token, branch);
      
          // 2. ปรับโครงสร้างข้อมูลก่อนเก็บใน store
          const formattedSuppliers = res.data.supplier.map(supplier => ({
            ...supplier,
            branchName: res.data.name // เพิ่มชื่อสาขาเข้าไปในแต่ละ supplier (optional)
          }));
      
          // 3. เก็บข้อมูลทั้งสองแบบใน store
          set({ 
            suppliers: formattedSuppliers, // Array ของ suppliers
            currentBranch: { // เก็บข้อมูลสาขาปัจจุบัน (optional)
              ...res.data,
              suppliers: formattedSuppliers
            }
          });
      
        } catch (error) {
          console.error("Failed to fetch suppliers:", error);
          // ควรจัดการ error ใน UI ด้วย (เช่น set error state)
          set({ supplierError: error.message });
        }
      },
    actionSearchFilters: async (arg) => {
        try {
            const res = await searchFilters(arg)
            set({ products: res.data })

        } catch (err) {
            console.log(err)
        }
    },

    getTotalPrice: () => {
        return get().carts.reduce((total, item) => {
            return total + item.price * item.count;
        }, 0);

    },

    clearCart: () => set({ carts: [] }),
})

const usePersist = {
    name: 'alphatech-store',
    storage: createJSONStorage(() => localStorage)
}

const useAlphaTechStore = create(persist(alphaTechStore, usePersist))

export default useAlphaTechStore